# Appendix C - Final Security Assessment: /home/kali/workspace/abb-hackathon/sgc-gatekeeper-testbed

Generated (UTC): 2026-11-15T07:52:07.051244+00:00

## 1. Executive summary

Automated analysis produced **300 scanner findings** for **/home/kali/workspace/abb-hackathon/sgc-gatekeeper-testbed**.

These are automated detections requiring review, not independently confirmed vulnerabilities.

### Severity distribution

| Severity | Count |
| --- | --- |
| CRITICAL | 8 |
| HIGH | 34 |
| MEDIUM | 65 |
| LOW | 6 |
| INFO | 6 |
| UNKNOWN | 181 |

### Top five risks

1. **CRITICAL** - Stripe Secret Key (Trivy, config.py:6)
2. **CRITICAL** - Google (GCP) Service-account (Trivy, credentials.json:2)
3. **CRITICAL** - Directory traversal in Django (Trivy, requirements.txt:?)
4. **CRITICAL** - The (1) django.http.HttpResponseRedirect and (2) django.http.HttpRespo ... (Trivy, requirements.txt:?)
5. **CRITICAL** - python-django: unexpected code execution using reverse() (Trivy, requirements.txt:?)

### Main limitations

Automated findings have not been independently verified. Reachability, runtime exploitability and business impact are not assessed. Offline vulnerability database freshness cannot be established without database timestamps.

## 2. Scope

| Field | Value |
| --- | --- |
| Repository | /home/kali/workspace/abb-hackathon/sgc-gatekeeper-testbed |
| Repository URL | https://github.com/Dhruti-Avadhani2004/sgc-gatekeeper-testbed.git |
| Commit | 5a1844a031d36d741ef96801f1b913a50f14d1ef |
| Branch | main |
| Folders scanned | /home/kali/workspace/abb-hackathon/sgc-gatekeeper-testbed/dotnet-aspgoat |
| Known exclusions | node_modules |
| Scanner output directory | /home/kali/workspace/abb-hackathon/scanner_output |

Exclusions listed here are only those recorded in the available reports or metadata. Different scanners may have different exclusions.

## 3. Environment

| Field | Recorded value |
| --- | --- |
| OS / VM | Linux-5.15.0-203-generic-x86_64-with-glibc2.35 |
| CPU architecture | 64 |
| Python version | 3.12.16 (main, Oct 26 2026, 15:28:01) [GCC 11.4.0] |
| Rule-set hashes | Not supplied |
| Vulnerability database timestamps | Not supplied |
| Trivy report timestamp | 2026-11-15T06:48:22.619564007Z |
| ScanCode scan start | 2026-11-15T074332.011307 |

### Scanner versions

| Scanner | Version |
| --- | --- |
| Semgrep | 1.185.0 |
| Trivy | 0.76.2 |
| ScanCode | 32.5.0 |
| Syft | 1.57.1 |

### Scanner input status

| Scanner | Input file | Status |
| --- | --- | --- |
| semgrep | semgrep_output.json | Present |
| trivy | trivy_output_offline.json | Present |
| bandit | bandit_output.json | Present |
| eslint | eslint_output.json | Present |
| gitleaks | gitleaks_output.json | Present |
| scancode | scancode_output.json | Present |
| cyclonedx | sbom_cyclonedx.json | Present |
| spdx | sbom_spdx.json | Present |
| dotnet | dotnet_output.txt | Present |

## 4. Method

| Scanner / format | Purpose | Availability |
| --- | --- | --- |
| semgrep | Rule-based static application security testing | Input present |
| bandit | Python static security analysis | Input present |
| eslint | JavaScript lint and security rules | Input present |
| trivy | Dependency and configuration security checks | Input present |
| gitleaks | Potential secret detection | Input present |
| scancode | License, copyright and package analysis | Input present |
| cyclonedx | CycloneDX software bill of materials | Input present |
| spdx | SPDX software bill of materials | Input present |
| dotnet | NuGet dependency vulnerability analysis | Input present |

Exact execution commands, scan options, offline cache configuration and rule provenance may require execution logs or additional metadata.

## 5. Results by repository

| Repository | Critical | High | Medium | Low | Info | Unknown | Confirmed | Unverified |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| /home/kali/workspace/abb-hackathon/sgc-gatekeeper-testbed | 8 | 34 | 65 | 6 | 6 | 181 | 0 | 300 |

All findings are classified as **unverified** until a human reviewer confirms their disposition. Scanner confidence does not establish exploitability.

### Findings by category

| Category | Count |
| --- | --- |
| Code quality | 136 |
| Dependency vulnerability | 58 |
| security | 46 |
| Security lint rule | 40 |
| Potential secret | 9 |
| best-practice | 7 |
| audit | 4 |

### Findings by scanner

| Scanner | Count |
| --- | --- |
| ESLint | 176 |
| Gitleaks | 5 |
| Semgrep | 57 |
| Trivy | 62 |

## 6. Top findings

### 1. Stripe Secret Key

| Field | Value |
| --- | --- |
| Finding ID | 0cc082048c4a5f5c |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | config.py:6 |
| Rule | stripe-secret-token |
| CWE | Not supplied |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | trivy_output_offline.json |
| Reference | Not supplied |

Evidence summary: Potential secret detected; value withheld.

### 2. Google (GCP) Service-account

| Field | Value |
| --- | --- |
| Finding ID | 6d99db479565218f |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | credentials.json:2 |
| Rule | gcp-service-account |
| CWE | Not supplied |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | trivy_output_offline.json |
| Reference | Not supplied |

Evidence summary: Potential secret detected; value withheld.

### 3. Directory traversal in Django

| Field | Value |
| --- | --- |
| Finding ID | 2a12737ecdff29df |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | requirements.txt |
| Rule | CVE-2011-0698 |
| CWE | CWE-22 |
| CVE / advisory | CVE-2011-0698 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 1.1.4, 1.2.5 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2011-0698 |

Evidence summary: Directory traversal vulnerability in Django 1.1.x before 1.1.4 and 1.2.x before 1.2.5 on Windows might allow remote attackers to read or execute files via a / (slash) character in a key in a session cookie, related to session replays.

### 4. The (1) django.http.HttpResponseRedirect and (2) django.http.HttpRespo ...

| Field | Value |
| --- | --- |
| Finding ID | 0a7904e03992c381 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | requirements.txt |
| Rule | CVE-2012-3442 |
| CWE | CWE-79 |
| CVE / advisory | CVE-2012-3442 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 1.3.2, 1.4.1 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2012-3442 |

Evidence summary: The (1) django.http.HttpResponseRedirect and (2) django.http.HttpResponsePermanentRedirect classes in Django before 1.3.2 and 1.4.x before 1.4.1 do not validate the scheme of a redirect target, which might allow remote attackers to conduct cross-site scripting (XSS) attacks via a data: URL.

### 5. python-django: unexpected code execution using reverse()

| Field | Value |
| --- | --- |
| Finding ID | 8cae1978e171c3c8 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | requirements.txt |
| Rule | CVE-2014-0472 |
| CWE | CWE-94 |
| CVE / advisory | CVE-2014-0472 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 1.4.11, 1.5.6, 1.6.3 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2014-0472 |

Evidence summary: The django.core.urlresolvers.reverse function in Django before 1.4.11, 1.5.x before 1.5.6, 1.6.x before 1.6.3, and 1.7.x before 1.7 beta 2 allows remote attackers to import and execute arbitrary Python modules by leveraging a view that constructs URLs using user input and a "dotted Python path."

### 6. Django: crafted email address allows account takeover

| Field | Value |
| --- | --- |
| Finding ID | 3fe4111f140e13aa |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | requirements.txt |
| Rule | CVE-2019-19844 |
| CWE | CWE-640 |
| CVE / advisory | CVE-2019-19844 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 1.11.27, 2.2.9, 3.0.1 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2019-19844 |

Evidence summary: Django before 1.11.27, 2.x before 2.2.9, and 3.x before 3.0.1 allows account takeover. A suitably crafted email address (that is equal to an existing user's email address after case transformation of Unicode characters) would allow an attacker to be sent a password reset token for the matched user account. (One mitigation in the new releases is to send password reset tokens only to the registered user email address.)

### 7. django: potential SQL injection via StringAgg(delimiter)

| Field | Value |
| --- | --- |
| Finding ID | ce738bb908addcc1 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | requirements.txt |
| Rule | CVE-2020-7471 |
| CWE | CWE-89 |
| CVE / advisory | CVE-2020-7471 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 1.11.28, 2.2.10, 3.0.3 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2020-7471 |

Evidence summary: Django 1.11 before 1.11.28, 2.2 before 2.2.10, and 3.0 before 3.0.3 allows SQL Injection if untrusted data is used as a StringAgg delimiter (e.g., in Django applications that offer downloads of data as a series of rows with a user-specified column delimiter). By passing a suitably crafted delimiter to a contrib.postgres.aggregates.StringAgg instance, it was possible to break escaping and inject malicious SQL.

### 8. django: Django SQL injection

| Field | Value |
| --- | --- |
| Finding ID | 3419da0467e6d239 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | requirements.txt |
| Rule | CVE-2025-64459 |
| CWE | CWE-89 |
| CVE / advisory | CVE-2025-64459 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 5.2.8, 5.1.14, 4.2.26 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2025-64459 |

Evidence summary: An issue was discovered in 5.1 before 5.1.14, 4.2 before 4.2.26, and 5.2 before 5.2.8. The methods 'QuerySet.filter()', 'QuerySet.exclude()', and 'QuerySet.get()', and the class 'Q()', are subject to SQL injection when using a suitably crafted dictionary, with dictionary expansion, as the '_connector' argument. Earlier, unsupported Django series (such as 5.0.x, 4.1.x, and 3.2.x) were not evaluated and may also be affected. Django would like to thank cyberstan for reporting this issue.

### 9. A query string parameter may contain a URL value that could cause the web application to redirect the request to a malicious website controlled by an attacker. Make sure to sanitize this parameter sufficiently.

| Field | Value |
| --- | --- |
| Finding ID | 2dbf78c41d0dd0f8 |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | Controllers/HomeController.cs:164 |
| Rule | scanner_output.semgrep-configs.csharp.lang.security.open-redirect |
| CWE | CWE-601 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://cwe.mitre.org/data/definitions/601.html |

Evidence summary: A query string parameter may contain a URL value that could cause the web application to redirect the request to a malicious website controlled by an attacker. Make sure to sanitize this parameter sufficiently.

### 10. By not specifying a USER, a program in the container may run as 'root'. This is a security hazard. If an attacker can control a process running as root, they may have control over the container. Ensure that the last USER

| Field | Value |
| --- | --- |
| Finding ID | 74650f3c7abae766 |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | Dockerfile:21 |
| Rule | scanner_output.semgrep-configs.dockerfile.security.missing-user-entrypoint |
| CWE | CWE-269 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A04_2021-Insecure_Design |

Evidence summary: By not specifying a USER, a program in the container may run as 'root'. This is a security hazard. If an attacker can control a process running as root, they may have control over the container. Ensure that the last USER in a Dockerfile is a USER other than 'root'.

### 11. User controlled data in methods like 'innerHTML', 'outerHTML' or 'document.write' is an anti-pattern that can lead to XSS vulnerabilities

| Field | Value |
| --- | --- |
| Finding ID | a1d313ce48d2c6e0 |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | wwwroot/LLM-js/ea.js:20 |
| Rule | scanner_output.semgrep-configs.javascript.browser.security.insecure-document-method |
| CWE | CWE-79 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A03_2021-Injection |

Evidence summary: User controlled data in methods like 'innerHTML', 'outerHTML' or 'document.write' is an anti-pattern that can lead to XSS vulnerabilities

### 12. User controlled data in a 'bubble.innerHTML' is an anti-pattern that can lead to XSS vulnerabilities

| Field | Value |
| --- | --- |
| Finding ID | f417c3bb63d6e49b |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | wwwroot/LLM-js/ea.js:20 |
| Rule | scanner_output.semgrep-configs.javascript.browser.security.insecure-innerhtml |
| CWE | CWE-79 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A03_2021-Injection |

Evidence summary: User controlled data in a 'bubble.innerHTML' is an anti-pattern that can lead to XSS vulnerabilities

### 13. User controlled data in methods like 'innerHTML', 'outerHTML' or 'document.write' is an anti-pattern that can lead to XSS vulnerabilities

| Field | Value |
| --- | --- |
| Finding ID | 9176aa92816c7cc3 |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | wwwroot/LLM-js/ioh.js:22 |
| Rule | scanner_output.semgrep-configs.javascript.browser.security.insecure-document-method |
| CWE | CWE-79 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A03_2021-Injection |

Evidence summary: User controlled data in methods like 'innerHTML', 'outerHTML' or 'document.write' is an anti-pattern that can lead to XSS vulnerabilities

### 14. User controlled data in a 'bubble.innerHTML' is an anti-pattern that can lead to XSS vulnerabilities

| Field | Value |
| --- | --- |
| Finding ID | 2f7d9e9b5d4acec1 |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | wwwroot/LLM-js/ioh.js:22 |
| Rule | scanner_output.semgrep-configs.javascript.browser.security.insecure-innerhtml |
| CWE | CWE-79 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A03_2021-Injection |

Evidence summary: User controlled data in a 'bubble.innerHTML' is an anti-pattern that can lead to XSS vulnerabilities

### 15. User controlled data in methods like 'innerHTML', 'outerHTML' or 'document.write' is an anti-pattern that can lead to XSS vulnerabilities

| Field | Value |
| --- | --- |
| Finding ID | 27453d770f5ada21 |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | wwwroot/LLM-js/pi.js:20 |
| Rule | scanner_output.semgrep-configs.javascript.browser.security.insecure-document-method |
| CWE | CWE-79 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A03_2021-Injection |

Evidence summary: User controlled data in methods like 'innerHTML', 'outerHTML' or 'document.write' is an anti-pattern that can lead to XSS vulnerabilities

### 16. User controlled data in a 'bubble.innerHTML' is an anti-pattern that can lead to XSS vulnerabilities

| Field | Value |
| --- | --- |
| Finding ID | 25d6701cd92b4f4f |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | wwwroot/LLM-js/pi.js:20 |
| Rule | scanner_output.semgrep-configs.javascript.browser.security.insecure-innerhtml |
| CWE | CWE-79 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A03_2021-Injection |

Evidence summary: User controlled data in a 'bubble.innerHTML' is an anti-pattern that can lead to XSS vulnerabilities

### 17. Asymmetric Private Key

| Field | Value |
| --- | --- |
| Finding ID | 4468cfb6100c9a15 |
| Scanner | Trivy |
| Severity | HIGH |
| Evidence location | config.py:9 |
| Rule | private-key |
| CWE | Not supplied |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | trivy_output_offline.json |
| Reference | Not supplied |

Evidence summary: Potential secret detected; value withheld.

### 18. The administrative interface in django.contrib.admin in Django before  ...

| Field | Value |
| --- | --- |
| Finding ID | 2fe1d903b82c2e29 |
| Scanner | Trivy |
| Severity | HIGH |
| Evidence location | requirements.txt |
| Rule | CVE-2010-4534 |
| CWE | CWE-264 |
| CVE / advisory | CVE-2010-4534 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 1.1.3, 1.2.4 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2010-4534 |

Evidence summary: The administrative interface in django.contrib.admin in Django before 1.1.3, 1.2.x before 1.2.4, and 1.3.x before 1.3 beta 1 does not properly restrict use of the query string to perform certain object filtering, which allows remote authenticated users to obtain sensitive information via a series of requests containing regular expressions, as demonstrated by a created_by__password__regex parameter.

### 19. Django 1.1.x before 1.1.4 and 1.2.x before 1.2.5 does not properly val ...

| Field | Value |
| --- | --- |
| Finding ID | 843d03448bbb9929 |
| Scanner | Trivy |
| Severity | HIGH |
| Evidence location | requirements.txt |
| Rule | CVE-2011-0696 |
| CWE | CWE-352 |
| CVE / advisory | CVE-2011-0696 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 1.1.4, 1.2.5 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2011-0696 |

Evidence summary: Django 1.1.x before 1.1.4 and 1.2.x before 1.2.5 does not properly validate HTTP requests that contain an X-Requested-With header, which makes it easier for remote attackers to conduct cross-site request forgery (CSRF) attacks via forged AJAX requests that leverage a "combination of browser plugins and redirects," a related issue to CVE-2011-0447.

### 20. The verify_exists functionality in the URLField implementation in Djan ...

| Field | Value |
| --- | --- |
| Finding ID | aaf630e80f8c0b0d |
| Scanner | Trivy |
| Severity | HIGH |
| Evidence location | requirements.txt |
| Rule | CVE-2011-4137 |
| CWE | CWE-399 |
| CVE / advisory | CVE-2011-4137 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 1.2.7, 1.3.1 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2011-4137 |

Evidence summary: The verify_exists functionality in the URLField implementation in Django before 1.2.7 and 1.3.x before 1.3.1 relies on Python libraries that attempt access to an arbitrary URL with no timeout, which allows remote attackers to cause a denial of service (resource consumption) via a URL associated with (1) a slow response, (2) a completed TCP connection with no application data sent, or (3) a large amount of application data, a related issue to CVE-2011-1521.

Only the first 20 of 300 findings are expanded here. Complete records are available in consolidated_findings.json.

## 7. Supply chain view

Package scanners identified **11 distinct package/version entries** after consolidation.

An SBOM package entry does not itself represent a vulnerability.

### Vulnerable packages and advisories

| Package | Installed | Advisory | Severity | Fixed version | Source |
| --- | --- | --- | --- | --- | --- |
| django | 1.2 | CVE-2011-0698 | CRITICAL | 1.1.4, 1.2.5 | Trivy |
| django | 1.2 | CVE-2012-3442 | CRITICAL | 1.3.2, 1.4.1 | Trivy |
| django | 1.2 | CVE-2014-0472 | CRITICAL | 1.4.11, 1.5.6, 1.6.3 | Trivy |
| django | 1.2 | CVE-2019-19844 | CRITICAL | 1.11.27, 2.2.9, 3.0.1 | Trivy |
| django | 1.2 | CVE-2020-7471 | CRITICAL | 1.11.28, 2.2.10, 3.0.3 | Trivy |
| django | 1.2 | CVE-2025-64459 | CRITICAL | 5.2.8, 5.1.14, 4.2.26 | Trivy |
| django | 1.2 | CVE-2010-4534 | HIGH | 1.1.3, 1.2.4 | Trivy |
| django | 1.2 | CVE-2011-0696 | HIGH | 1.1.4, 1.2.5 | Trivy |
| django | 1.2 | CVE-2011-4137 | HIGH | 1.2.7, 1.3.1 | Trivy |
| django | 1.2 | CVE-2011-4138 | HIGH | 1.2.7, 1.3.1 | Trivy |
| django | 1.2 | CVE-2011-4139 | HIGH | 1.2.7, 1.3.1 | Trivy |
| django | 1.2 | CVE-2011-4140 | HIGH | Not supplied | Trivy |
| django | 1.2 | CVE-2012-3443 | HIGH | 1.3.2, 1.4.1 | Trivy |
| django | 1.2 | CVE-2012-3444 | HIGH | 1.3.2, 1.4.1 | Trivy |
| django | 1.2 | CVE-2014-0473 | HIGH | 1.4.11, 1.5.6, 1.6.3 | Trivy |
| django | 1.2 | CVE-2014-0474 | HIGH | 1.4.11, 1.5.6, 1.6.3 | Trivy |
| django | 1.2 | CVE-2014-0480 | HIGH | 1.4.14, 1.5.9, 1.6.6 | Trivy |
| django | 1.2 | CVE-2014-0481 | HIGH | 1.4.14, 1.5.9, 1.6.6 | Trivy |
| django | 1.2 | CVE-2015-0221 | HIGH | 1.4.18, 1.6.10, 1.7.3 | Trivy |
| django | 1.2 | CVE-2015-5143 | HIGH | 1.4.21, 1.7.9, 1.8.3 | Trivy |
| django | 1.2 | CVE-2015-5144 | HIGH | 1.4.21, 1.7.9, 1.8.3 | Trivy |
| django | 1.2 | CVE-2016-7401 | HIGH | 1.8.15, 1.9.10 | Trivy |
| django | 1.2 | CVE-2022-36359 | HIGH | 3.2.15, 4.0.7 | Trivy |
| django | 1.2 | CVE-2025-57833 | HIGH | 4.2.24, 5.1.12, 5.2.6 | Trivy |
| django | 1.2 | CVE-2025-64458 | HIGH | 5.2.8, 5.1.14, 4.2.26 | Trivy |
| django | 1.2 | CVE-2026-15307 | HIGH | 5.2.17, 6.0.8 | Trivy |
| flask | 0.12 | CVE-2018-1000656 | HIGH | 0.12.3 | Trivy |
| flask | 0.12 | CVE-2019-1010083 | HIGH | 1.0 | Trivy |
| flask | 0.12 | CVE-2023-30861 | HIGH | 2.3.2, 2.2.5 | Trivy |
| requests | 2.19.0 | CVE-2018-18074 | HIGH | 2.20.0 | Trivy |
| django | 1.2 | CVE-2010-3082 | MEDIUM | 1.2.2 | Trivy |
| django | 1.2 | CVE-2010-4535 | MEDIUM | 1.1.3, 1.2.4 | Trivy |
| django | 1.2 | CVE-2011-0697 | MEDIUM | 1.1.4, 1.2.5 | Trivy |
| django | 1.2 | CVE-2011-4136 | MEDIUM | 1.2.7, 1.3.1 | Trivy |
| django | 1.2 | CVE-2014-0482 | MEDIUM | 1.4.14, 1.5.9, 1.6.6, 1.7c3 | Trivy |
| django | 1.2 | CVE-2014-0483 | MEDIUM | 1.4.14, 1.5.9, 1.6.6, 1.7c3 | Trivy |
| django | 1.2 | CVE-2015-0219 | MEDIUM | 1.4.18, 1.6.10, 1.7.3 | Trivy |
| django | 1.2 | CVE-2015-0220 | MEDIUM | 1.4.18, 1.6.10, 1.7.3 | Trivy |
| django | 1.2 | CVE-2015-2241 | MEDIUM | 1.7.6, 1.8b2 | Trivy |
| django | 1.2 | CVE-2015-2317 | MEDIUM | 1.4.20, 1.6.11, 1.7.7, 1.8c1 | Trivy |
| django | 1.2 | CVE-2016-2512 | MEDIUM | 1.8.10, 1.9.3 | Trivy |
| django | 1.2 | CVE-2016-6186 | MEDIUM | 1.8.14, 1.9.8, 1.10rc1 | Trivy |
| django | 1.2 | CVE-2021-33203 | MEDIUM | 2.2.24, 3.1.12, 3.2.4 | Trivy |
| django | 1.2 | CVE-2024-45231 | MEDIUM | 5.1.1, 5.0.9, 4.2.16 | Trivy |
| django | 1.2 | CVE-2025-48432 | MEDIUM | 5.2.2, 5.1.10, 4.2.22 | Trivy |
| django | 1.2 | CVE-2026-15830 | MEDIUM | 5.2.17, 6.0.8, 6.1.1 | Trivy |
| django | 1.2 | CVE-2026-53877 | MEDIUM | 5.2.16, 6.0.7 | Trivy |
| django | 1.2 | CVE-2026-53878 | MEDIUM | 5.2.16, 6.0.7 | Trivy |
| requests | 2.19.0 | CVE-2023-32681 | MEDIUM | 2.31.0 | Trivy |
| requests | 2.19.0 | CVE-2024-35195 | MEDIUM | 2.32.0 | Trivy |
| requests | 2.19.0 | CVE-2024-47081 | MEDIUM | 2.32.4 | Trivy |
| requests | 2.19.0 | CVE-2026-25645 | MEDIUM | 2.33.0 | Trivy |
| django | 1.2 | CVE-2016-2513 | LOW | 1.8.10, 1.9.3 | Trivy |
| django | 1.2 | CVE-2026-48587 | LOW | 5.2.15, 6.0.6 | Trivy |
| django | 1.2 | CVE-2026-48588 | LOW | 5.2.16, 6.0.7 | Trivy |
| django | 1.2 | CVE-2026-6873 | LOW | 5.2.15, 6.0.6 | Trivy |
| django | 1.2 | CVE-2026-8404 | LOW | 5.2.15, 6.0.6 | Trivy |
| flask | 0.12 | CVE-2026-27205 | LOW | 3.1.3 | Trivy |

### Package inventory

| Package | Version / constraint | Direct / transitive | License | Source |
| --- | --- | --- | --- | --- |
| /home/kali/workspace/abb-hackathon/sgc-gatekeeper-testbed/dotnet-aspgoat |  | Unknown | Not identified | Syft SPDX |
| actions/cache | v4 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| actions/checkout | v4 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| actions/setup-dotnet | v3 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| django | 1.2 | Unknown | Not assessed | Trivy |
| docker/build-push-action | v6 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| docker/login-action | v3 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| docker/metadata-action | v5 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| docker/setup-buildx-action | v3 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| flask | 0.12 | Unknown | Not assessed | Trivy |
| requests | 2.19.0 | Unknown | Not assessed | Trivy |

### Repository license

mit

Detected licenses are not a legal compliance determination. Unknown dependency relationships are not inferred.

## 8. Remediation outcomes

No baseline/post-remediation comparison, patch evidence or test results were supplied.

Before-and-after counts, verified fixes and closure status are **not assessed**.

## 9. Limitations

- Static analysis and dependency scanners can produce false positives and false negatives.
- Reachability, exploitability, runtime controls and business impact have not been validated.
- Offline vulnerability databases and rules may be stale. Report timestamps do not prove database freshness.
- A missing or failed scanner must not be interpreted as reporting zero vulnerabilities.
- Source coverage, excluded files and unsupported language features may not be fully established by scanner reports alone.
- Potential secret findings require validation. Matched secret values are withheld.

## 10. Recommendations

1. **Triage ownership:** Assign each finding to a responsible repository or component owner.
2. **Validate findings:** Confirm whether flagged code and dependencies are deployed and reachable. Record false positives.
3. **Fix timelines:** Establish severity-based remediation SLAs using an approved policy.
4. **CI integration:** Integrate scanners into CI and define policy gates with an exception process.
5. **Supply chain:** Update vulnerable dependencies to compatible patched versions and review license obligations.
6. **Offline maintenance:** Periodically refresh scanner rules and vulnerability databases through an approved process.
7. **Remediation verification:** Rerun scans and tests after fixes. Preserve baseline and follow-up reports.

