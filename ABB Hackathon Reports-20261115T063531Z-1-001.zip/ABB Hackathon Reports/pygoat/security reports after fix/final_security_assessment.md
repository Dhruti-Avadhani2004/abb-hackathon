# Appendix C - Final Security Assessment: C:/Users/dhrut/OneDrive/Desktop/abb_hackathon/pygoat

Generated (UTC): 2026-11-15T04:57:41.166722+00:00

## 1. Executive summary

Automated analysis produced **1126 scanner findings** for **C:/Users/dhrut/OneDrive/Desktop/abb_hackathon/pygoat**.

These are automated detections requiring review, not independently confirmed vulnerabilities.

### Severity distribution

| Severity | Count |
| --- | --- |
| CRITICAL | 33 |
| HIGH | 287 |
| MEDIUM | 590 |
| LOW | 155 |
| INFO | 46 |
| UNKNOWN | 15 |

### Top five risks

1. **CRITICAL** - python-pillow: insufficent fix for CVE-2020-35654 due to incorrect error checking in TiffDecode.c (Trivy, dockerized_labs/a9_uckv_lab/requirements.txt:?)
2. **CRITICAL** - python-pillow: Buffer overflow in image convert function (Trivy, dockerized_labs/a9_uckv_lab/requirements.txt:?)
3. **CRITICAL** - python-pillow: PIL.ImageMath.eval allows evaluation of arbitrary expressions (Trivy, dockerized_labs/a9_uckv_lab/requirements.txt:?)
4. **CRITICAL** - pillow: Arbitrary Code Execution via the environment parameter (Trivy, dockerized_labs/a9_uckv_lab/requirements.txt:?)
5. **CRITICAL** - pillow: Pillow: Heap buffer overflow in _tiffWriteProc when saving TIFF to BytesIO (Trivy, dockerized_labs/a9_uckv_lab/requirements.txt:?)

### Main limitations

Automated findings have not been independently verified. Reachability, runtime exploitability and business impact are not assessed. Offline vulnerability database freshness cannot be established without database timestamps.

## 2. Scope

| Field | Value |
| --- | --- |
| Repository | C:/Users/dhrut/OneDrive/Desktop/abb_hackathon/pygoat |
| Repository URL | https://github.com/adeyosemanputra/pygoat.git |
| Commit | 2aa4cc14f251e4a780e94e200aed6b36a5b15c21 |
| Branch | master |
| Folders scanned | C:\Users\dhrut\OneDrive\Desktop\abb_hackathon\pygoat |
| Known exclusions | node_modules |
| Scanner output directory | C:\Users\dhrut\OneDrive\Desktop\abb_hackathon\scanner_output |

Exclusions listed here are only those recorded in the available reports or metadata. Different scanners may have different exclusions.

## 3. Environment

| Field | Recorded value |
| --- | --- |
| OS / VM | Windows-11-10.0.26200-SP0 |
| CPU architecture | 64 |
| Python version | 3.12.0 (tags/v3.12.0:0fb18b0, Oct  2 2023, 13:03:39) [MSC v.1935 64 bit (AMD64)] |
| Rule-set hashes | Not supplied |
| Vulnerability database timestamps | Not supplied |
| Trivy report timestamp | 2026-11-15T10:23:52.5992224+05:30 |
| ScanCode scan start | 2026-11-15T045420.495883 |

### Scanner versions

| Scanner | Version |
| --- | --- |
| Semgrep | 1.185.0 |
| Trivy | 0.76.2 |
| ScanCode | 32.5.0 |
| Syft | 1.55.0 |

### Scanner input status

| Scanner | Input file | Status |
| --- | --- | --- |
| semgrep | semgrep_output.json | Present |
| trivy | trivy_output_offline.json | Present |
| bandit | bandit_output.json | Present |
| eslint | eslint_output.json | Present |
| gitleaks | gitleaks_output.json | Present |
| scancode | scancode_output.json | Present |
| cyclonedx | sbom_cyclonedx.json | Present |
| spdx | sbom_spdx.json | Present |
| dotnet | dotnet_output.txt | Present |

## 4. Method

| Scanner / format | Purpose | Availability |
| --- | --- | --- |
| semgrep | Rule-based static application security testing | Input present |
| bandit | Python static security analysis | Input present |
| eslint | JavaScript lint and security rules | Input present |
| trivy | Dependency and configuration security checks | Input present |
| gitleaks | Potential secret detection | Input present |
| scancode | License, copyright and package analysis | Input present |
| cyclonedx | CycloneDX software bill of materials | Input present |
| spdx | SPDX software bill of materials | Input present |
| dotnet | NuGet dependency vulnerability analysis | Input present |

Exact execution commands, scan options, offline cache configuration and rule provenance may require execution logs or additional metadata.

## 5. Results by repository

| Repository | Critical | High | Medium | Low | Info | Unknown | Confirmed | Unverified |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C:/Users/dhrut/OneDrive/Desktop/abb_hackathon/pygoat | 33 | 287 | 590 | 155 | 46 | 15 | 0 | 1126 |

All findings are classified as **unverified** until a human reviewer confirms their disposition. Scanner confidence does not establish exploitability.

### Findings by category

| Category | Count |
| --- | --- |
| Dependency vulnerability | 572 |
| security | 235 |
| SAST | 128 |
| maintainability | 59 |
| Misconfiguration | 53 |
| best-practice | 45 |
| Potential secret | 14 |
| correctness | 14 |
| Code quality | 3 |
| Security lint rule | 2 |
| audit | 1 |

### Findings by scanner

| Scanner | Count |
| --- | --- |
| Bandit | 128 |
| ESLint | 5 |
| Gitleaks | 10 |
| Semgrep | 354 |
| Trivy | 629 |

## 6. Top findings

### 1. python-pillow: insufficent fix for CVE-2020-35654 due to incorrect error checking in TiffDecode.c

| Field | Value |
| --- | --- |
| Finding ID | 08129a07a8d8cf71 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/a9_uckv_lab/requirements.txt |
| Rule | CVE-2021-25289 |
| CWE | CWE-787 |
| CVE / advisory | CVE-2021-25289 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 8.1.1 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2021-25289 |

Evidence summary: An issue was discovered in Pillow before 8.1.1. TiffDecode has a heap-based buffer overflow when decoding crafted YCbCr files because of certain interpretation conflicts with LibTIFF in RGBA mode. NOTE: this issue exists because of an incomplete fix for CVE-2020-35654.

### 2. python-pillow: Buffer overflow in image convert function

| Field | Value |
| --- | --- |
| Finding ID | b625953c5827050b |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/a9_uckv_lab/requirements.txt |
| Rule | CVE-2021-34552 |
| CWE | CWE-120 |
| CVE / advisory | CVE-2021-34552 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 8.3.0 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2021-34552 |

Evidence summary: Pillow through 8.2.0 and PIL (aka Python Imaging Library) through 1.1.7 allow an attacker to pass controlled parameters directly into a convert function to trigger a buffer overflow in Convert.c.

### 3. python-pillow: PIL.ImageMath.eval allows evaluation of arbitrary expressions

| Field | Value |
| --- | --- |
| Finding ID | 673d94591c89fb2b |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/a9_uckv_lab/requirements.txt |
| Rule | CVE-2022-22817 |
| CWE | Not supplied |
| CVE / advisory | CVE-2022-22817 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 9.0.1 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2022-22817 |

Evidence summary: PIL.ImageMath.eval in Pillow before 9.0.0 allows evaluation of arbitrary expressions, such as ones that use the Python exec method. A lambda expression could also be used.

### 4. pillow: Arbitrary Code Execution via the environment parameter

| Field | Value |
| --- | --- |
| Finding ID | d9a0b65dc8f6ccf2 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/a9_uckv_lab/requirements.txt |
| Rule | CVE-2023-50447 |
| CWE | CWE-94, CWE-95 |
| CVE / advisory | CVE-2023-50447 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 10.2.0 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2023-50447 |

Evidence summary: Pillow through 10.1.0 allows PIL.ImageMath.eval Arbitrary Code Execution via the environment parameter, a different vulnerability than CVE-2022-22817 (which was about the expression parameter).

### 5. pillow: Pillow: Heap buffer overflow in _tiffWriteProc when saving TIFF to BytesIO

| Field | Value |
| --- | --- |
| Finding ID | c249e0fa812f7550 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/a9_uckv_lab/requirements.txt |
| Rule | CVE-2026-112393 |
| CWE | CWE-122 |
| CVE / advisory | CVE-2026-112393 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 13.0.0 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2026-112393 |

Evidence summary: Pillow is a Python imaging library. From 2.0.0 until 13.0.0, Pillow has a heap buffer overflow and stale-heap disclosure in _tiffWriteProc when saving compressed TIFF data through libtiff to a target without a usable fileno(), such as BytesIO. The callback sizes its allocation from the prior buffer size instead of the current write position, allowing an attacker-controlled out-of-line TIFF tag or retained ICC profile to be copied beyond the allocation after libtiff seeks forward. This overflow c

### 6. pillow: Pillow: Heap buffer overflow in FlashPix (FPX) JPEG decoding leads to code execution

| Field | Value |
| --- | --- |
| Finding ID | 0ce64361048e02c7 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/a9_uckv_lab/requirements.txt |
| Rule | CVE-2026-112398 |
| CWE | CWE-122, CWE-787 |
| CVE / advisory | CVE-2026-112398 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 13.0.0 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2026-112398 |

Evidence summary: Pillow is a Python imaging library. Prior to 13.0.0, Pillow's FlashPix JPEG-tile decoder can write decoded scanlines beyond the allocated tile buffer. FlashPix (FPX) JPEG decoding selects raw mode LA with two bytes per pixel, while an unrecognized JPEG mode can be decoded as JCS_UNKNOWN with four components, causing ImagingJpegDecode to write four-component scanlines into the two-byte tile buffer. An attacker can supply a crafted OLE2 FlashPix file to an application with the optional olefile dep

### 7. pillow: Pillow: Heap buffer overflow in ImagingJpegDecode

| Field | Value |
| --- | --- |
| Finding ID | c338011e1561dc92 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/a9_uckv_lab/requirements.txt |
| Rule | CVE-2026-112403 |
| CWE | CWE-122 |
| CVE / advisory | CVE-2026-112403 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 13.0.0 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2026-112403 |

Evidence summary: Pillow is a Python imaging library. Prior to 13.0.0, Pillow's JPEG decoder can write a full-width scanline into a buffer sized for a requested draft scale. ImagingJpegDecode does not verify libjpeg's actual output width and component count after scaling is requested, and an 8-bit lossless SOF3 JPEG decoded by a build linked to libjpeg-turbo 3.x can ignore the requested downscaling geometry. An attacker can supply such a JPEG to an application that uses draft() or thumbnail() to request downscali

### 8. pillow: Pillow: Argument Injection in Ghostscript call, potentially leading into RCE

| Field | Value |
| --- | --- |
| Finding ID | 8cdbe9a0077d1830 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/a9_uckv_lab/requirements.txt |
| Rule | CVE-2026-112900 |
| CWE | CWE-78, CWE-88 |
| CVE / advisory | CVE-2026-112900 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 13.0.0 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2026-112900 |

Evidence summary: Pillow is a Python imaging library. From 2.6.0 until 13.0.0, Pillow is vulnerable to argument injection when invoking Ghostscript for EPS input. EpsImagePlugin.Ghostscript passes a caller-controlled input filename after -f without converting it to a safe absolute path, so a name beginning with a hyphen can be interpreted as a Ghostscript option. An attacker who controls the filename can inject Ghostscript arguments. Arbitrary command execution specifically requires a leading @ argument-file file

### 9. PyYAML: command execution through python/object/apply constructor in FullLoader

| Field | Value |
| --- | --- |
| Finding ID | 405b2ddc9da65e41 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/a9_uckv_lab/requirements.txt |
| Rule | CVE-2019-20477 |
| CWE | CWE-502 |
| CVE / advisory | CVE-2019-20477 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 5.2 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2019-20477 |

Evidence summary: PyYAML 5.1 through 5.1.2 has insufficient restrictions on the load and load_all functions because of a class deserialization issue, e.g., Popen is a class in the subprocess module. NOTE: this issue exists because of an incomplete fix for CVE-2017-18342.

### 10. PyYAML: incomplete fix for CVE-2020-1747

| Field | Value |
| --- | --- |
| Finding ID | ebdb8526f917cc34 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/a9_uckv_lab/requirements.txt |
| Rule | CVE-2020-14343 |
| CWE | CWE-20 |
| CVE / advisory | CVE-2020-14343 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 5.4 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2020-14343 |

Evidence summary: A vulnerability was discovered in the PyYAML library in versions before 5.4, where it is susceptible to arbitrary code execution when it processes untrusted YAML files through the full_load method or with the FullLoader loader. Applications that use the library to process untrusted input may be vulnerable to this flaw. This flaw allows an attacker to execute arbitrary code on the system by abusing the python/object/new constructor. This flaw is due to an incomplete fix for CVE-2020-1747.

### 11. PyYAML: arbitrary command execution through python/object/new when FullLoader is used

| Field | Value |
| --- | --- |
| Finding ID | 9f1ccbe2864f2b6f |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/a9_uckv_lab/requirements.txt |
| Rule | CVE-2020-1747 |
| CWE | CWE-20 |
| CVE / advisory | CVE-2020-1747 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 5.3.1 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2020-1747 |

Evidence summary: A vulnerability was discovered in the PyYAML library in versions before 5.3.1, where it is susceptible to arbitrary code execution when it processes untrusted YAML files through the full_load method or with the FullLoader loader. Applications that use the library to process untrusted input may be vulnerable to this flaw. An attacker could use this flaw to execute arbitrary code on the system by abusing the python/object/new constructor.

### 12. Stripe Secret Key

| Field | Value |
| --- | --- |
| Finding ID | 577679199c9a24f7 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/package_injection_lab/app.py:11 |
| Rule | stripe-secret-token |
| CWE | Not supplied |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | trivy_output_offline.json |
| Reference | Not supplied |

Evidence summary: Potential secret detected; value withheld.

### 13. Secrets passed via 'build-args' or envs or copied secret files

| Field | Value |
| --- | --- |
| Finding ID | 1e3f529d6f625840 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/sec_misconfig/Dockerfile:12 |
| Rule | DS-0031 |
| CWE | Not supplied |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/misconfig/ds-0031 |

Evidence summary: Passing secrets via 'build-args' or envs or copying secret files can leak them out

### 14. Secrets passed via 'build-args' or envs or copied secret files

| Field | Value |
| --- | --- |
| Finding ID | f3c4a3c01ef07a22 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/sec_misconfig/Dockerfile:13 |
| Rule | DS-0031 |
| CWE | Not supplied |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/misconfig/ds-0031 |

Evidence summary: Passing secrets via 'build-args' or envs or copying secret files can leak them out

### 15. Stripe Secret Key

| Field | Value |
| --- | --- |
| Finding ID | 60c8653b8406df95 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/sec_misconfig/app.py:13 |
| Rule | stripe-secret-token |
| CWE | Not supplied |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | trivy_output_offline.json |
| Reference | Not supplied |

Evidence summary: Potential secret detected; value withheld.

### 16. AWS Access Key ID

| Field | Value |
| --- | --- |
| Finding ID | 8de03f905d45c478 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/sec_misconfig/app.py:58 |
| Rule | aws-access-key-id |
| CWE | Not supplied |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | trivy_output_offline.json |
| Reference | Not supplied |

Evidence summary: Potential secret detected; value withheld.

### 17. Stripe Secret Key

| Field | Value |
| --- | --- |
| Finding ID | e270958bf2384937 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/sec_misconfig/app.py:60 |
| Rule | stripe-secret-token |
| CWE | Not supplied |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | trivy_output_offline.json |
| Reference | Not supplied |

Evidence summary: Potential secret detected; value withheld.

### 18. pyjwt: PyJWT: Authentication bypass via improper public key validation

| Field | Value |
| --- | --- |
| Finding ID | 646a3e170f0a7e58 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/sec_misconfig/requirements.txt |
| Rule | CVE-2026-102268 |
| CWE | CWE-347 |
| CVE / advisory | CVE-2026-102268 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 2.14.0 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2026-102268 |

Evidence summary: PyJWT is a Python implementation of JSON Web Token standards. Prior to 2.14.0, is_pem_format in jwt/utils.py is affected because is_pem_format does not recognize every PEM representation accepted by the cryptography loader. This occurs when an application mixes HMAC and asymmetric algorithms and supplies a mutated public-key PEM as raw key bytes. As a result, HMACAlgorithm.prepare_key treats the unrecognized asymmetric public key as an HMAC secret. Consequently, an attacker who knows the public 

### 19. python-django: Potential bypass of validation when uploading multiple files using one form field

| Field | Value |
| --- | --- |
| Finding ID | b96a83d5825496f0 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/sensitive_data_exposure/requirements.txt |
| Rule | CVE-2023-31047 |
| CWE | CWE-20, CWE-862 |
| CVE / advisory | CVE-2023-31047 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 3.2.19, 4.1.9, 4.2.1 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2023-31047 |

Evidence summary: In Django 3.2 before 3.2.19, 4.x before 4.1.9, and 4.2 before 4.2.1, it was possible to bypass validation when using one form field to upload multiple files. This multiple upload has never been supported by forms.FileField or forms.ImageField (only the last uploaded file was validated). However, Django's "Uploading multiple files" documentation suggested otherwise.

### 20. django: Django SQL injection

| Field | Value |
| --- | --- |
| Finding ID | f1af0683e5cffe46 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | dockerized_labs/sensitive_data_exposure/requirements.txt |
| Rule | CVE-2025-64459 |
| CWE | CWE-89 |
| CVE / advisory | CVE-2025-64459 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 5.2.8, 5.1.14, 4.2.26 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2025-64459 |

Evidence summary: An issue was discovered in 5.1 before 5.1.14, 4.2 before 4.2.26, and 5.2 before 5.2.8. The methods 'QuerySet.filter()', 'QuerySet.exclude()', and 'QuerySet.get()', and the class 'Q()', are subject to SQL injection when using a suitably crafted dictionary, with dictionary expansion, as the '_connector' argument. Earlier, unsupported Django series (such as 5.0.x, 4.1.x, and 3.2.x) were not evaluated and may also be affected. Django would like to thank cyberstan for reporting this issue.

Only the first 20 of 1126 findings are expanded here. Complete records are available in consolidated_findings.json.

## 7. Supply chain view

Package scanners identified **95 distinct package/version entries** after consolidation.

An SBOM package entry does not itself represent a vulnerability.

### Vulnerable packages and advisories

| Package | Installed | Advisory | Severity | Fixed version | Source |
| --- | --- | --- | --- | --- | --- |
| pillow | 8.0.0 | CVE-2021-25289 | CRITICAL | 8.1.1 | Trivy |
| pillow | 8.0.0 | CVE-2021-34552 | CRITICAL | 8.3.0 | Trivy |
| pillow | 8.0.0 | CVE-2022-22817 | CRITICAL | 9.0.1 | Trivy |
| pillow | 8.0.0 | CVE-2023-50447 | CRITICAL | 10.2.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-112393 | CRITICAL | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-112398 | CRITICAL | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-112403 | CRITICAL | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-112900 | CRITICAL | 13.0.0 | Trivy |
| pyyaml | 5.1 | CVE-2019-20477 | CRITICAL | 5.2 | Trivy |
| pyyaml | 5.1 | CVE-2020-14343 | CRITICAL | 5.4 | Trivy |
| pyyaml | 5.1 | CVE-2020-1747 | CRITICAL | 5.3.1 | Trivy |
| PyJWT | 2.8.0 | CVE-2026-102268 | CRITICAL | 2.14.0 | Trivy |
| django | 3.2.18 | CVE-2023-31047 | CRITICAL | 3.2.19, 4.1.9, 4.2.1 | Trivy |
| django | 3.2.18 | CVE-2025-64459 | CRITICAL | 5.2.8, 5.1.14, 4.2.26 | Trivy |
| Django | 4.2 | CVE-2023-31047 | CRITICAL | 3.2.19, 4.1.9, 4.2.1 | Trivy |
| Django | 4.2 | CVE-2024-42005 | CRITICAL | 5.0.8, 4.2.15 | Trivy |
| Django | 4.2 | CVE-2025-64459 | CRITICAL | 5.2.8, 5.1.14, 4.2.26 | Trivy |
| Pillow | 12.1.0 | CVE-2026-112393 | CRITICAL | 13.0.0 | Trivy |
| Pillow | 12.1.0 | CVE-2026-112398 | CRITICAL | 13.0.0 | Trivy |
| Pillow | 12.1.0 | CVE-2026-112403 | CRITICAL | 13.0.0 | Trivy |
| Pillow | 12.1.0 | CVE-2026-112900 | CRITICAL | 13.0.0 | Trivy |
| Pillow | 12.1.0 | CVE-2026-96639 | CRITICAL | 13.0.0 | Trivy |
| PyJWT | 2.4.0 | CVE-2026-102268 | CRITICAL | 2.14.0 | Trivy |
| PyYAML | 5.1 | CVE-2019-20477 | CRITICAL | 5.2 | Trivy |
| PyYAML | 5.1 | CVE-2020-14343 | CRITICAL | 5.4 | Trivy |
| PyYAML | 5.1 | CVE-2020-1747 | CRITICAL | 5.3.1 | Trivy |
| certifi | 2022.12.7 | GHSA-6q48-6c7w-9gw2 | CRITICAL | 2026.10.18 | Trivy |
| Werkzeug | 2.3.7 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |
| Werkzeug | 2.3.7 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |
| Werkzeug | 2.3.7 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |
| flask | 2.0.1 | CVE-2023-30861 | HIGH | 2.3.2, 2.2.5 | Trivy |
| gunicorn | 20.1.0 | CVE-2024-1135 | HIGH | 22.0.0 | Trivy |
| gunicorn | 20.1.0 | CVE-2024-6827 | HIGH | 22.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2020-35653 | HIGH | 8.1.0 | Trivy |
| pillow | 8.0.0 | CVE-2020-35654 | HIGH | 8.1.0 | Trivy |
| pillow | 8.0.0 | CVE-2021-23437 | HIGH | 8.3.2 | Trivy |
| pillow | 8.0.0 | CVE-2021-25287 | HIGH | 8.2.0 | Trivy |
| pillow | 8.0.0 | CVE-2021-25288 | HIGH | 8.2.0 | Trivy |
| pillow | 8.0.0 | CVE-2021-25290 | HIGH | 8.1.1 | Trivy |
| pillow | 8.0.0 | CVE-2021-25291 | HIGH | 8.2.0 | Trivy |
| pillow | 8.0.0 | CVE-2021-25293 | HIGH | 8.1.1 | Trivy |
| pillow | 8.0.0 | CVE-2021-27921 | HIGH | 8.1.2 | Trivy |
| pillow | 8.0.0 | CVE-2021-27922 | HIGH | 8.1.2 | Trivy |
| pillow | 8.0.0 | CVE-2021-27923 | HIGH | 8.1.2 | Trivy |
| pillow | 8.0.0 | CVE-2021-28675 | HIGH | 8.2.0 | Trivy |
| pillow | 8.0.0 | CVE-2021-28676 | HIGH | 8.2.0 | Trivy |
| pillow | 8.0.0 | CVE-2021-28677 | HIGH | 8.2.0 | Trivy |
| pillow | 8.0.0 | CVE-2022-24303 | HIGH | 9.0.1 | Trivy |
| pillow | 8.0.0 | CVE-2022-45198 | HIGH | 9.2.0 | Trivy |
| pillow | 8.0.0 | CVE-2023-44271 | HIGH | 10.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2023-4863 | HIGH | 10.0.1 | Trivy |
| pillow | 8.0.0 | CVE-2024-28219 | HIGH | 10.3.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-112390 | HIGH | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-112392 | HIGH | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-112397 | HIGH | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-112402 | HIGH | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-112406 | HIGH | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-112892 | HIGH | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-112894 | HIGH | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-112895 | HIGH | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-112896 | HIGH | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-112897 | HIGH | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-112902 | HIGH | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-128067 | HIGH | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-54058 | HIGH | 12.3.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-54059 | HIGH | 12.3.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-54060 | HIGH | 12.3.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-55379 | HIGH | 12.3.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-55380 | HIGH | 12.3.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-59197 | HIGH | 12.3.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-59199 | HIGH | 12.3.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-59200 | HIGH | 12.3.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-59205 | HIGH | 12.3.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-96637 | HIGH | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-96640 | HIGH | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-96642 | HIGH | 13.0.0 | Trivy |
| pillow | 8.0.0 | CVE-2026-96644 | HIGH | 13.0.0 | Trivy |
| werkzeug | 2.0.1 | CVE-2023-25577 | HIGH | 2.2.3 | Trivy |
| werkzeug | 2.0.1 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |
| werkzeug | 3.0.1 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |
| Werkzeug | 2.3.7 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |
| Flask | 2.0.1 | CVE-2023-30861 | HIGH | 2.3.2, 2.2.5 | Trivy |
| Werkzeug | 2.0.1 | CVE-2023-25577 | HIGH | 2.2.3 | Trivy |
| Werkzeug | 2.0.1 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |
| flask | 2.0.1 | CVE-2023-30861 | HIGH | 2.3.2, 2.2.5 | Trivy |
| werkzeug | 2.0.1 | CVE-2023-25577 | HIGH | 2.2.3 | Trivy |
| werkzeug | 2.0.1 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |
| Werkzeug | 2.3.7 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |
| Werkzeug | 3.0.1 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |
| Werkzeug | 2.2.2 | CVE-2023-25577 | HIGH | 2.2.3 | Trivy |
| Werkzeug | 2.2.2 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |
| Werkzeug | 2.3.7 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |
| Flask | 2.0.1 | CVE-2023-30861 | HIGH | 2.3.2, 2.2.5 | Trivy |
| Werkzeug | 2.0.1 | CVE-2023-25577 | HIGH | 2.2.3 | Trivy |
| Werkzeug | 2.0.1 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |
| Flask | 2.0.1 | CVE-2023-30861 | HIGH | 2.3.2, 2.2.5 | Trivy |
| Werkzeug | 2.0.1 | CVE-2023-25577 | HIGH | 2.2.3 | Trivy |
| Werkzeug | 2.0.1 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |
| Werkzeug | 2.0.3 | CVE-2023-25577 | HIGH | 2.2.3 | Trivy |
| Werkzeug | 2.0.3 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |

Additional dependency findings are available in the JSON and CSV outputs.

### Package inventory

| Package | Version / constraint | Direct / transitive | License | Source |
| --- | --- | --- | --- | --- |
| actions/checkout | v4 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| actions/setup-python | v5 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| argon2-cffi | 21.3.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| argon2-cffi-bindings | 21.2.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| asgiref | 3.6.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| black | 26.1.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| blinker | 1.6.2 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| C:\Users\dhrut\OneDrive\Desktop\abb_hackathon\pygoat |  | Unknown | Not identified | Syft SPDX |
| certifi | 2022.12.7 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| cffi | 2.0.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| charset-normalizer | 3.0.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| click | 8.1.7 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| crispy-bootstrap4 | 2022.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| cryptography | 39.0.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| defusedxml | 0.7.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| dj-database-url | 0.5.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| django | 3.2.18 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| Django | 4.2 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| django-allauth | 0.52.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| django-crispy-forms | 1.14.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| django-crispy-forms | 2.3 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| docker | 7.1.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| flask | 2.0.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| flask | 2.0.3 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| Flask | 2.2.5 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| Flask | 2.3.3 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| Flask | 3.0.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| flask | 3.0.2 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| Flask-Login | 0.5.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| flask-sqlalchemy | 3.1.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| gunicorn | 20.1.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| gunicorn | 23.0.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| hadolint/hadolint-action | v3.1.0 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| idna | 3.4 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| itsdangerous | 2.1.2 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| jinja2 | 3.0.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| Jinja2 | 3.1.2 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| MarkupSafe | 2.1.3 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| oauthlib | 3.2.2 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| Pillow | 12.1.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| pillow | 8.0.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| pkg:pypi/argon2-cffi-bindings@21.2.0 | argon2-cffi-bindings==21.2.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/argon2-cffi@21.3.0 | argon2-cffi==21.3.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/asgiref@3.6.0 | asgiref==3.6.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/black@26.1.0 | black==26.1.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/certifi@2022.12.7 | certifi==2022.12.7 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/cffi@2.0.0 | cffi==2.0.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/charset-normalizer@3.0.1 | charset-normalizer==3.0.1 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/crispy-bootstrap4@2022.1 | crispy-bootstrap4==2022.1 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/cryptography@39.0.1 | cryptography==39.0.1 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/defusedxml@0.7.1 | defusedxml==0.7.1 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/dj-database-url@0.5.0 | dj-database-url==0.5.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/django-allauth@0.52.0 | django-allauth==0.52.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/django-crispy-forms@2.3 | django-crispy-forms==2.3 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/django@4.2 | Django==4.2 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/docker@7.1.0 | docker==7.1.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/gunicorn@23.0.0 | gunicorn==23.0.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/idna@3.4 | idna==3.4 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/oauthlib@3.2.2 | oauthlib==3.2.2 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/pillow@12.1.0 | Pillow==12.1.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/pre-commit@4.5.1 | pre_commit==4.5.1 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/pycparser@2.21 | pycparser==2.21 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/pyjwt@2.4.0 | PyJWT==2.4.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/python3-openid@3.2.0 | python3-openid==3.2.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/pytz@2020.1 | pytz==2020.1 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/pyyaml@5.1 | PyYAML==5.1 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/requests-oauthlib@1.3.1 | requests-oauthlib==1.3.1 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/requests@2.28.2 | requests==2.28.2 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/sqlparse@0.3.1 | sqlparse==0.3.1 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/urllib3@1.26.9 | urllib3==1.26.9 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/werkzeug@2.1.2 | Werkzeug==2.1.2 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/whitenoise@6.2.0 | whitenoise==6.2.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/zipp@3.8.0 | zipp==3.8.0 | Direct | Not assessed | ScanCode dependency |
| pre_commit | 4.5.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| pycparser | 2.21 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| pygoat | 1.2.0 | Unknown | MIT | ScanCode |
| PyJWT | 2.4.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| PyJWT | 2.8.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| python-dotenv | 0.21.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| python3-openid | 3.2.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| pytz | 2020.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| pyyaml | 5.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| requests | 2.28.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| requests | 2.28.2 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| requests-oauthlib | 1.3.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| sqlparse | 0.3.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| urllib3 | 1.26.9 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| werkzeug | 2.0.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| Werkzeug | 2.0.3 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| Werkzeug | 2.1.2 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| Werkzeug | 2.2.2 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| Werkzeug | 2.3.7 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| werkzeug | 3.0.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| whitenoise | 6.2.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| zipp | 3.8.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |

### Repository license

mit

Detected licenses are not a legal compliance determination. Unknown dependency relationships are not inferred.

## 8. Remediation outcomes

No baseline/post-remediation comparison, patch evidence or test results were supplied.

Before-and-after counts, verified fixes and closure status are **not assessed**.

## 9. Limitations

- Static analysis and dependency scanners can produce false positives and false negatives.
- Reachability, exploitability, runtime controls and business impact have not been validated.
- Offline vulnerability databases and rules may be stale. Report timestamps do not prove database freshness.
- A missing or failed scanner must not be interpreted as reporting zero vulnerabilities.
- Source coverage, excluded files and unsupported language features may not be fully established by scanner reports alone.
- Potential secret findings require validation. Matched secret values are withheld.

## 10. Recommendations

1. **Triage ownership:** Assign each finding to a responsible repository or component owner.
2. **Validate findings:** Confirm whether flagged code and dependencies are deployed and reachable. Record false positives.
3. **Fix timelines:** Establish severity-based remediation SLAs using an approved policy.
4. **CI integration:** Integrate scanners into CI and define policy gates with an exception process.
5. **Supply chain:** Update vulnerable dependencies to compatible patched versions and review license obligations.
6. **Offline maintenance:** Periodically refresh scanner rules and vulnerability databases through an approved process.
7. **Remediation verification:** Rerun scans and tests after fixes. Preserve baseline and follow-up reports.

