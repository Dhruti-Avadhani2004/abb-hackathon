# Appendix C - Final Security Assessment: C:/Users/dhrut/OneDrive/Desktop/abb_hackathon/dvb-lab

Generated (UTC): 2026-11-15T06:27:33.623669+00:00

## 1. Executive summary

Automated analysis produced **424 scanner findings** for **C:/Users/dhrut/OneDrive/Desktop/abb_hackathon/dvb-lab**.

These are automated detections requiring review, not independently confirmed vulnerabilities.

### Severity distribution

| Severity | Count |
| --- | --- |
| CRITICAL | 6 |
| HIGH | 82 |
| MEDIUM | 196 |
| LOW | 49 |
| INFO | 74 |
| UNKNOWN | 17 |

### Top five risks

1. **CRITICAL** - pyjwt: PyJWT: Authentication bypass via improper public key validation (Trivy, backend/requirements.txt:?)
2. **CRITICAL** - PyYAML: incomplete fix for CVE-2020-1747 (Trivy, backend/requirements.txt:?)
3. **CRITICAL** - Stripe Secret Key (Trivy, backend/routes/admin_routes.py:21)
4. **CRITICAL** - Stripe Secret Key (Trivy, eval/mutate.py:63)
5. **CRITICAL** - Stripe Secret Key (Trivy, eval/mutate.py:64)

### Main limitations

Automated findings have not been independently verified. Reachability, runtime exploitability and business impact are not assessed. Offline vulnerability database freshness cannot be established without database timestamps.

## 2. Scope

| Field | Value |
| --- | --- |
| Repository | C:/Users/dhrut/OneDrive/Desktop/abb_hackathon/dvb-lab |
| Repository URL | https://github.com/mamgad/DVBLab.git |
| Commit | cdcd3174a5712d58aaa99b059b76ef2504a75aee |
| Branch | main |
| Folders scanned | C:\Users\dhrut\OneDrive\Desktop\abb_hackathon\dvb-lab |
| Known exclusions | node_modules |
| Scanner output directory | C:\Users\dhrut\OneDrive\Desktop\abb_hackathon\scanner_output |

Exclusions listed here are only those recorded in the available reports or metadata. Different scanners may have different exclusions.

## 3. Environment

| Field | Recorded value |
| --- | --- |
| OS / VM | Windows-11-10.0.26200-SP0 |
| CPU architecture | 64 |
| Python version | 3.12.0 (tags/v3.12.0:0fb18b0, Oct  2 2023, 13:03:39) [MSC v.1935 64 bit (AMD64)] |
| Rule-set hashes | Not supplied |
| Vulnerability database timestamps | Not supplied |
| Trivy report timestamp | 2026-11-15T11:55:06.685704+05:30 |
| ScanCode scan start | 2026-11-15T062533.728719 |

### Scanner versions

| Scanner | Version |
| --- | --- |
| Semgrep | 1.185.0 |
| Trivy | 0.76.2 |
| ScanCode | 32.5.0 |
| Syft | 1.55.0 |

### Scanner input status

| Scanner | Input file | Status |
| --- | --- | --- |
| semgrep | semgrep_output.json | Present |
| trivy | trivy_output_offline.json | Present |
| bandit | bandit_output.json | Present |
| eslint | eslint_output.json | Present |
| gitleaks | gitleaks_output.json | Present |
| scancode | scancode_output.json | Present |
| cyclonedx | sbom_cyclonedx.json | Present |
| spdx | sbom_spdx.json | Present |
| dotnet | dotnet_output.txt | Present |

## 4. Method

| Scanner / format | Purpose | Availability |
| --- | --- | --- |
| semgrep | Rule-based static application security testing | Input present |
| bandit | Python static security analysis | Input present |
| eslint | JavaScript lint and security rules | Input present |
| trivy | Dependency and configuration security checks | Input present |
| gitleaks | Potential secret detection | Input present |
| scancode | License, copyright and package analysis | Input present |
| cyclonedx | CycloneDX software bill of materials | Input present |
| spdx | SPDX software bill of materials | Input present |
| dotnet | NuGet dependency vulnerability analysis | Input present |

Exact execution commands, scan options, offline cache configuration and rule provenance may require execution logs or additional metadata.

## 5. Results by repository

| Repository | Critical | High | Medium | Low | Info | Unknown | Confirmed | Unverified |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C:/Users/dhrut/OneDrive/Desktop/abb_hackathon/dvb-lab | 6 | 82 | 196 | 49 | 74 | 17 | 0 | 424 |

All findings are classified as **unverified** until a human reviewer confirms their disposition. Scanner confidence does not establish exploitability.

### Findings by category

| Category | Count |
| --- | --- |
| security | 129 |
| SAST | 102 |
| best-practice | 79 |
| portability | 56 |
| Dependency vulnerability | 32 |
| Potential secret | 16 |
| Code quality | 3 |
| Misconfiguration | 3 |
| Security lint rule | 2 |
| maintainability | 2 |

### Findings by scanner

| Scanner | Count |
| --- | --- |
| Bandit | 102 |
| ESLint | 5 |
| Gitleaks | 12 |
| Semgrep | 266 |
| Trivy | 39 |

## 6. Top findings

### 1. pyjwt: PyJWT: Authentication bypass via improper public key validation

| Field | Value |
| --- | --- |
| Finding ID | cd690859cd7e5c5a |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | backend/requirements.txt |
| Rule | CVE-2026-102268 |
| CWE | CWE-347 |
| CVE / advisory | CVE-2026-102268 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 2.14.0 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2026-102268 |

Evidence summary: PyJWT is a Python implementation of JSON Web Token standards. Prior to 2.14.0, is_pem_format in jwt/utils.py is affected because is_pem_format does not recognize every PEM representation accepted by the cryptography loader. This occurs when an application mixes HMAC and asymmetric algorithms and supplies a mutated public-key PEM as raw key bytes. As a result, HMACAlgorithm.prepare_key treats the unrecognized asymmetric public key as an HMAC secret. Consequently, an attacker who knows the public 

### 2. PyYAML: incomplete fix for CVE-2020-1747

| Field | Value |
| --- | --- |
| Finding ID | 5f4ec09be140a572 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | backend/requirements.txt |
| Rule | CVE-2020-14343 |
| CWE | CWE-20 |
| CVE / advisory | CVE-2020-14343 |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Review affected package and update to a compatible fixed version: 5.4 |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/nvd/cve-2020-14343 |

Evidence summary: A vulnerability was discovered in the PyYAML library in versions before 5.4, where it is susceptible to arbitrary code execution when it processes untrusted YAML files through the full_load method or with the FullLoader loader. Applications that use the library to process untrusted input may be vulnerable to this flaw. This flaw allows an attacker to execute arbitrary code on the system by abusing the python/object/new constructor. This flaw is due to an incomplete fix for CVE-2020-1747.

### 3. Stripe Secret Key

| Field | Value |
| --- | --- |
| Finding ID | b4df37d6c09d199c |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | backend/routes/admin_routes.py:21 |
| Rule | stripe-secret-token |
| CWE | Not supplied |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | trivy_output_offline.json |
| Reference | Not supplied |

Evidence summary: Potential secret detected; value withheld.

### 4. Stripe Secret Key

| Field | Value |
| --- | --- |
| Finding ID | 120bafb4c0869cf3 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | eval/mutate.py:63 |
| Rule | stripe-secret-token |
| CWE | Not supplied |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | trivy_output_offline.json |
| Reference | Not supplied |

Evidence summary: Potential secret detected; value withheld.

### 5. Stripe Secret Key

| Field | Value |
| --- | --- |
| Finding ID | 8012ca8c8b2a32d6 |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | eval/mutate.py:64 |
| Rule | stripe-secret-token |
| CWE | Not supplied |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | trivy_output_offline.json |
| Reference | Not supplied |

Evidence summary: Potential secret detected; value withheld.

### 6. GitHub Personal Access Token

| Field | Value |
| --- | --- |
| Finding ID | 9cd2941088012f8a |
| Scanner | Trivy |
| Severity | CRITICAL |
| Evidence location | eval/mutate.py:70 |
| Rule | github-pat |
| CWE | Not supplied |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | trivy_output_offline.json |
| Reference | Not supplied |

Evidence summary: Potential secret detected; value withheld.

### 7. hashlib

| Field | Value |
| --- | --- |
| Finding ID | c6500af1923414dd |
| Scanner | Bandit |
| Severity | HIGH |
| Evidence location | backend/models.py:27 |
| Rule | B324 |
| CWE | CWE-327 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | bandit_output.json |
| Reference | https://bandit.readthedocs.io/en/1.9.4/plugins/b324_hashlib.html |

Evidence summary: Use of weak MD5 hash for security. Consider usedforsecurity=False

### 8. hashlib

| Field | Value |
| --- | --- |
| Finding ID | e7bb35666048098e |
| Scanner | Bandit |
| Severity | HIGH |
| Evidence location | backend/models.py:30 |
| Rule | B324 |
| CWE | CWE-327 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | bandit_output.json |
| Reference | https://bandit.readthedocs.io/en/1.9.4/plugins/b324_hashlib.html |

Evidence summary: Use of weak MD5 hash for security. Consider usedforsecurity=False

### 9. request_with_no_cert_validation

| Field | Value |
| --- | --- |
| Finding ID | 7c3732f73acf0966 |
| Scanner | Bandit |
| Severity | HIGH |
| Evidence location | backend/routes/admin_routes.py:121 |
| Rule | B501 |
| CWE | CWE-295 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | bandit_output.json |
| Reference | https://bandit.readthedocs.io/en/1.9.4/plugins/b501_request_with_no_cert_validation.html |

Evidence summary: Call to requests with verify=False disabling SSL certificate checks, security issue.

### 10. hashlib

| Field | Value |
| --- | --- |
| Finding ID | 0d9019b229a3bbdd |
| Scanner | Bandit |
| Severity | HIGH |
| Evidence location | backend/routes/admin_routes.py:379 |
| Rule | B324 |
| CWE | CWE-327 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | bandit_output.json |
| Reference | https://bandit.readthedocs.io/en/1.9.4/plugins/b324_hashlib.html |

Evidence summary: Use of weak SHA1 hash for security. Consider usedforsecurity=False

### 11. hashlib

| Field | Value |
| --- | --- |
| Finding ID | b68990dfe1709336 |
| Scanner | Bandit |
| Severity | HIGH |
| Evidence location | backend/routes/admin_routes.py:393 |
| Rule | B324 |
| CWE | CWE-327 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | bandit_output.json |
| Reference | https://bandit.readthedocs.io/en/1.9.4/plugins/b324_hashlib.html |

Evidence summary: Use of weak MD5 hash for security. Consider usedforsecurity=False

### 12. subprocess_popen_with_shell_equals_true

| Field | Value |
| --- | --- |
| Finding ID | 128b4124e63fc088 |
| Scanner | Bandit |
| Severity | HIGH |
| Evidence location | backend/routes/admin_routes.py:44 |
| Rule | B602 |
| CWE | CWE-78 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | bandit_output.json |
| Reference | https://bandit.readthedocs.io/en/1.9.4/plugins/b602_subprocess_popen_with_shell_equals_true.html |

Evidence summary: subprocess call with shell=True identified, security issue.

### 13. start_process_with_a_shell

| Field | Value |
| --- | --- |
| Finding ID | 81d8f64b4285b8d6 |
| Scanner | Bandit |
| Severity | HIGH |
| Evidence location | backend/routes/admin_routes.py:54 |
| Rule | B605 |
| CWE | CWE-78 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | bandit_output.json |
| Reference | https://bandit.readthedocs.io/en/1.9.4/plugins/b605_start_process_with_a_shell.html |

Evidence summary: Starting a process with a shell, possible injection detected, security issue.

### 14. subprocess_popen_with_shell_equals_true

| Field | Value |
| --- | --- |
| Finding ID | ff89858bf3a2de76 |
| Scanner | Bandit |
| Severity | HIGH |
| Evidence location | backend/routes/admin_routes.py:67 |
| Rule | B602 |
| CWE | CWE-78 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | bandit_output.json |
| Reference | https://bandit.readthedocs.io/en/1.9.4/plugins/b602_subprocess_popen_with_shell_equals_true.html |

Evidence summary: subprocess call with shell=True identified, security issue.

### 15. subprocess_popen_with_shell_equals_true

| Field | Value |
| --- | --- |
| Finding ID | bf1674c8593ceff3 |
| Scanner | Bandit |
| Severity | HIGH |
| Evidence location | backend/routes/admin_routes.py:86 |
| Rule | B602 |
| CWE | CWE-78 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | bandit_output.json |
| Reference | https://bandit.readthedocs.io/en/1.9.4/plugins/b602_subprocess_popen_with_shell_equals_true.html |

Evidence summary: subprocess call with shell=True identified, security issue.

### 16. hashlib

| Field | Value |
| --- | --- |
| Finding ID | ebaed658c29381e0 |
| Scanner | Bandit |
| Severity | HIGH |
| Evidence location | backend/routes/auth_routes.py:175 |
| Rule | B324 |
| CWE | CWE-327 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | bandit_output.json |
| Reference | https://bandit.readthedocs.io/en/1.9.4/plugins/b324_hashlib.html |

Evidence summary: Use of weak MD5 hash for security. Consider usedforsecurity=False

### 17. hashlib

| Field | Value |
| --- | --- |
| Finding ID | ca94e1f94f3bb1b9 |
| Scanner | Bandit |
| Severity | HIGH |
| Evidence location | backend/routes/auth_routes.py:203 |
| Rule | B324 |
| CWE | CWE-327 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | bandit_output.json |
| Reference | https://bandit.readthedocs.io/en/1.9.4/plugins/b324_hashlib.html |

Evidence summary: Use of weak MD5 hash for security. Consider usedforsecurity=False

### 18. hashlib

| Field | Value |
| --- | --- |
| Finding ID | 31907b3574573d8f |
| Scanner | Bandit |
| Severity | HIGH |
| Evidence location | backend/routes/auth_routes.py:21 |
| Rule | B324 |
| CWE | CWE-327 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | bandit_output.json |
| Reference | https://bandit.readthedocs.io/en/1.9.4/plugins/b324_hashlib.html |

Evidence summary: Use of weak MD5 hash for security. Consider usedforsecurity=False

### 19. Using variable interpolation '${{...}}' with 'github' context data in a 'run:' step could allow an attacker to inject their own code into the runner. This would allow them to steal secrets and code. 'github' context data

| Field | Value |
| --- | --- |
| Finding ID | 638e04cf9caa48a3 |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | .github/workflows/vygl-scan.yml:13 |
| Rule | scanner_output.semgrep-configs.yaml.github-actions.security.run-shell-injection |
| CWE | CWE-78 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://docs.github.com/en/actions/learn-github-actions/security-hardening-for-github-actions#understanding-the-risk-of-script-injections |

Evidence summary: Using variable interpolation '${{...}}' with 'github' context data in a 'run:' step could allow an attacker to inject their own code into the runner. This would allow them to steal secrets and code. 'github' context data can have arbitrary user input and should be treated as untrusted. Instead, use an intermediate environment variable with 'env:' to store the data and use the environment variable in the 'run:' script. Be sure to use double-quotes the environment variable, like this: "$ENVVAR".

### 20. By not specifying a USER, a program in the container may run as 'root'. This is a security hazard. If an attacker can control a process running as root, they may have control over the container. Ensure that the last USER

| Field | Value |
| --- | --- |
| Finding ID | bc84fffbe509d47d |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | backend/Dockerfile:12 |
| Rule | scanner_output.semgrep-configs.dockerfile.security.missing-user |
| CWE | CWE-250 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A04_2021-Insecure_Design |

Evidence summary: By not specifying a USER, a program in the container may run as 'root'. This is a security hazard. If an attacker can control a process running as root, they may have control over the container. Ensure that the last USER in a Dockerfile is a USER other than 'root'.

Only the first 20 of 424 findings are expanded here. Complete records are available in consolidated_findings.json.

## 7. Supply chain view

Package scanners identified **36 distinct package/version entries** after consolidation.

An SBOM package entry does not itself represent a vulnerability.

### Vulnerable packages and advisories

| Package | Installed | Advisory | Severity | Fixed version | Source |
| --- | --- | --- | --- | --- | --- |
| PyJWT | 2.1.0 | CVE-2026-102268 | CRITICAL | 2.14.0 | Trivy |
| PyYAML | 5.3.1 | CVE-2020-14343 | CRITICAL | 5.4 | Trivy |
| Flask | 2.0.1 | CVE-2023-30861 | HIGH | 2.3.2, 2.2.5 | Trivy |
| Flask-CORS | 3.0.10 | CVE-2024-6221 | HIGH | 4.0.2 | Trivy |
| PyJWT | 2.1.0 | CVE-2022-29217 | HIGH | 2.4.0 | Trivy |
| PyJWT | 2.1.0 | CVE-2026-102267 | HIGH | 2.14.0 | Trivy |
| PyJWT | 2.1.0 | CVE-2026-32597 | HIGH | 2.12.0 | Trivy |
| PyJWT | 2.1.0 | CVE-2026-48526 | HIGH | 2.13.0 | Trivy |
| PyJWT | 2.1.0 | GHSA-pxh4-856f-4h89 | HIGH | 2.14.0 | Trivy |
| Werkzeug | 2.0.1 | CVE-2023-25577 | HIGH | 2.2.3 | Trivy |
| Werkzeug | 2.0.1 | CVE-2024-34069 | HIGH | 3.0.3 | Trivy |
| Flask-CORS | 3.0.10 | CVE-2024-1681 | MEDIUM | 4.0.1 | Trivy |
| Flask-CORS | 3.0.10 | CVE-2024-6839 | MEDIUM | 6.0.0 | Trivy |
| Flask-CORS | 3.0.10 | CVE-2024-6844 | MEDIUM | 6.0.0 | Trivy |
| Flask-CORS | 3.0.10 | CVE-2024-6866 | MEDIUM | 6.0.0 | Trivy |
| PyJWT | 2.1.0 | CVE-2026-101917 | MEDIUM | 2.14.0 | Trivy |
| PyJWT | 2.1.0 | CVE-2026-101918 | MEDIUM | 2.15.0 | Trivy |
| PyJWT | 2.1.0 | CVE-2026-102269 | MEDIUM | 2.14.0 | Trivy |
| PyJWT | 2.1.0 | CVE-2026-102270 | MEDIUM | 2.14.0 | Trivy |
| PyJWT | 2.1.0 | CVE-2026-102275 | MEDIUM | 2.15.0 | Trivy |
| PyJWT | 2.1.0 | CVE-2026-48522 | MEDIUM | 2.13.0 | Trivy |
| Werkzeug | 2.0.1 | CVE-2023-46136 | MEDIUM | 3.0.1, 2.3.8 | Trivy |
| Werkzeug | 2.0.1 | CVE-2024-49766 | MEDIUM | 3.0.6 | Trivy |
| Werkzeug | 2.0.1 | CVE-2024-49767 | MEDIUM | 3.0.6 | Trivy |
| Werkzeug | 2.0.1 | CVE-2025-66221 | MEDIUM | 3.1.4 | Trivy |
| Werkzeug | 2.0.1 | CVE-2026-102598 | MEDIUM | 3.1.9 | Trivy |
| Werkzeug | 2.0.1 | CVE-2026-21860 | MEDIUM | 3.1.5 | Trivy |
| Werkzeug | 2.0.1 | CVE-2026-27199 | MEDIUM | 3.1.6 | Trivy |
| python-dotenv | 0.19.0 | CVE-2026-28684 | MEDIUM | 1.2.2 | Trivy |
| Flask | 2.0.1 | CVE-2026-27205 | LOW | 3.1.3 | Trivy |
| PyJWT | 2.1.0 | CVE-2026-48524 | LOW | 2.13.0 | Trivy |
| Werkzeug | 2.0.1 | CVE-2023-23934 | LOW | 2.2.3 | Trivy |

### Package inventory

| Package | Version / constraint | Direct / transitive | License | Source |
| --- | --- | --- | --- | --- |
| actions/checkout | v4 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| C:\Users\dhrut\OneDrive\Desktop\abb_hackathon\dvb-lab |  | Unknown | Not identified | Syft SPDX |
| Flask | 2.0.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| Flask-CORS | 3.0.10 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| Flask-Login | 0.5.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| Flask-SQLAlchemy | 2.5.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| pkg:npm/%40radix-ui/react-alert-dialog | ^1.0.5 | Direct | Not assessed | ScanCode dependency |
| pkg:npm/%40testing-library/jest-dom | ^5.17.0 | Direct | Not assessed | ScanCode dependency |
| pkg:npm/%40testing-library/react | ^13.4.0 | Direct | Not assessed | ScanCode dependency |
| pkg:npm/%40testing-library/user-event | ^13.5.0 | Direct | Not assessed | ScanCode dependency |
| pkg:npm/autoprefixer | ^10.4.16 | Direct | Not assessed | ScanCode dependency |
| pkg:npm/class-variance-authority | ^0.7.0 | Direct | Not assessed | ScanCode dependency |
| pkg:npm/clsx | ^2.0.0 | Direct | Not assessed | ScanCode dependency |
| pkg:npm/lucide-react | ^0.263.1 | Direct | Not assessed | ScanCode dependency |
| pkg:npm/postcss | ^8.4.31 | Direct | Not assessed | ScanCode dependency |
| pkg:npm/react | ^18.2.0 | Direct | Not assessed | ScanCode dependency |
| pkg:npm/react-dom | ^18.2.0 | Direct | Not assessed | ScanCode dependency |
| pkg:npm/react-scripts | 5.0.1 | Direct | Not assessed | ScanCode dependency |
| pkg:npm/tailwind-merge | ^2.0.0 | Direct | Not assessed | ScanCode dependency |
| pkg:npm/tailwindcss | ^3.3.0 | Direct | Not assessed | ScanCode dependency |
| pkg:npm/tailwindcss-animate | ^1.0.7 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/flask-cors@3.0.10 | Flask-CORS==3.0.10 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/flask-login@0.5.0 | Flask-Login==0.5.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/flask-sqlalchemy@2.5.1 | Flask-SQLAlchemy==2.5.1 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/flask@2.0.1 | Flask==2.0.1 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/pyjwt@2.1.0 | PyJWT==2.1.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/python-dotenv@0.19.0 | python-dotenv==0.19.0 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/pyyaml@5.3.1 | PyYAML==5.3.1 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/sqlalchemy@1.4.23 | SQLAlchemy==1.4.23 | Direct | Not assessed | ScanCode dependency |
| pkg:pypi/werkzeug@2.0.1 | Werkzeug==2.0.1 | Direct | Not assessed | ScanCode dependency |
| PyJWT | 2.1.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| python-dotenv | 0.19.0 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| PyYAML | 5.3.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| SQLAlchemy | 1.4.23 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |
| vulnerable-bank-frontend | 0.1.0 | Unknown | Not identified | ScanCode |
| Werkzeug | 2.0.1 | Unknown | Not assessed | Trivy, Syft CycloneDX, Syft SPDX |

### Repository license

Not identified

Detected licenses are not a legal compliance determination. Unknown dependency relationships are not inferred.

## 8. Remediation outcomes

No baseline/post-remediation comparison, patch evidence or test results were supplied.

Before-and-after counts, verified fixes and closure status are **not assessed**.

## 9. Limitations

- Static analysis and dependency scanners can produce false positives and false negatives.
- Reachability, exploitability, runtime controls and business impact have not been validated.
- Offline vulnerability databases and rules may be stale. Report timestamps do not prove database freshness.
- A missing or failed scanner must not be interpreted as reporting zero vulnerabilities.
- Source coverage, excluded files and unsupported language features may not be fully established by scanner reports alone.
- Potential secret findings require validation. Matched secret values are withheld.

## 10. Recommendations

1. **Triage ownership:** Assign each finding to a responsible repository or component owner.
2. **Validate findings:** Confirm whether flagged code and dependencies are deployed and reachable. Record false positives.
3. **Fix timelines:** Establish severity-based remediation SLAs using an approved policy.
4. **CI integration:** Integrate scanners into CI and define policy gates with an exception process.
5. **Supply chain:** Update vulnerable dependencies to compatible patched versions and review license obligations.
6. **Offline maintenance:** Periodically refresh scanner rules and vulnerability databases through an approved process.
7. **Remediation verification:** Rerun scans and tests after fixes. Preserve baseline and follow-up reports.

