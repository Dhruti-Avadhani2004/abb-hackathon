# Appendix C - Final Security Assessment: C:/Users/dhrut/OneDrive/Desktop/abb_hackathon/dotnet-aspgoat

Generated (UTC): 2026-11-15T02:33:21.280871+00:00

## 1. Executive summary

Automated analysis produced **69 scanner findings** for **C:/Users/dhrut/OneDrive/Desktop/abb_hackathon/dotnet-aspgoat**.

These are automated detections requiring review, not independently confirmed vulnerabilities.

### Severity distribution

| Severity | Count |
| --- | --- |
| CRITICAL | 0 |
| HIGH | 9 |
| MEDIUM | 43 |
| LOW | 1 |
| INFO | 6 |
| UNKNOWN | 10 |

### Top five risks

1. **HIGH** - A query string parameter may contain a URL value that could cause the web application to redirect the request to a malicious website controlled by an attacker. Make sure to sanitize this parameter sufficiently. (Semgrep, Controllers/HomeController.cs:164)
2. **HIGH** - By not specifying a USER, a program in the container may run as 'root'. This is a security hazard. If an attacker can control a process running as root, they may have control over the container. Ensure that the last USER (Semgrep, Dockerfile:21)
3. **HIGH** - User controlled data in methods like 'innerHTML', 'outerHTML' or 'document.write' is an anti-pattern that can lead to XSS vulnerabilities (Semgrep, wwwroot/LLM-js/ea.js:20)
4. **HIGH** - User controlled data in a 'bubble.innerHTML' is an anti-pattern that can lead to XSS vulnerabilities (Semgrep, wwwroot/LLM-js/ea.js:20)
5. **HIGH** - User controlled data in methods like 'innerHTML', 'outerHTML' or 'document.write' is an anti-pattern that can lead to XSS vulnerabilities (Semgrep, wwwroot/LLM-js/ioh.js:22)

### Main limitations

Automated findings have not been independently verified. Reachability, runtime exploitability and business impact are not assessed. Offline vulnerability database freshness cannot be established without database timestamps.

## 2. Scope

| Field | Value |
| --- | --- |
| Repository | C:/Users/dhrut/OneDrive/Desktop/abb_hackathon/dotnet-aspgoat |
| Repository URL | https://github.com/Soham7-dev/AspGoat.git |
| Commit | db3153f5dae036a9d67e12be22548299855c6b40 |
| Branch | main |
| Folders scanned | C:\Users\dhrut\OneDrive\Desktop\abb_hackathon\dotnet-aspgoat |
| Known exclusions | node_modules |
| Scanner output directory | C:\Users\dhrut\OneDrive\Desktop\abb_hackathon\scanner_output |

Exclusions listed here are only those recorded in the available reports or metadata. Different scanners may have different exclusions.

## 3. Environment

| Field | Recorded value |
| --- | --- |
| OS / VM | Windows-11-10.0.26200-SP0 |
| CPU architecture | 64 |
| Python version | 3.12.0 (tags/v3.12.0:0fb18b0, Oct  2 2023, 13:03:39) [MSC v.1935 64 bit (AMD64)] |
| Rule-set hashes | Not supplied |
| Vulnerability database timestamps | Not supplied |
| Trivy report timestamp | 2026-11-15T07:53:37.9396854+05:30 |
| ScanCode scan start | 2026-11-15T022422.909290 |

### Scanner versions

| Scanner | Version |
| --- | --- |
| Semgrep | 1.185.0 |
| Trivy | 0.76.2 |
| ScanCode | 32.5.0 |
| Syft | 1.55.0 |

### Scanner input status

| Scanner | Input file | Status |
| --- | --- | --- |
| semgrep | semgrep_output.json | Present |
| trivy | trivy_output_offline.json | Present |
| bandit | bandit_output.json | Present |
| eslint | eslint_output.json | Present |
| gitleaks | gitleaks_output.json | Present |
| scancode | scancode_output.json | Present |
| cyclonedx | sbom_cyclonedx.json | Present |
| spdx | sbom_spdx.json | Present |
| dotnet | dotnet_output.txt | Present |

## 4. Method

| Scanner / format | Purpose | Availability |
| --- | --- | --- |
| semgrep | Rule-based static application security testing | Input present |
| bandit | Python static security analysis | Input present |
| eslint | JavaScript lint and security rules | Input present |
| trivy | Dependency and configuration security checks | Input present |
| gitleaks | Potential secret detection | Input present |
| scancode | License, copyright and package analysis | Input present |
| cyclonedx | CycloneDX software bill of materials | Input present |
| spdx | SPDX software bill of materials | Input present |
| dotnet | NuGet dependency vulnerability analysis | Input present |

Exact execution commands, scan options, offline cache configuration and rule provenance may require execution logs or additional metadata.

## 5. Results by repository

| Repository | Critical | High | Medium | Low | Info | Unknown | Confirmed | Unverified |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C:/Users/dhrut/OneDrive/Desktop/abb_hackathon/dotnet-aspgoat | 0 | 9 | 43 | 1 | 6 | 10 | 0 | 69 |

All findings are classified as **unverified** until a human reviewer confirms their disposition. Scanner confidence does not establish exploitability.

### Findings by category

| Category | Count |
| --- | --- |
| security | 46 |
| best-practice | 7 |
| Potential secret | 5 |
| audit | 4 |
| Code quality | 3 |
| Misconfiguration | 2 |
| Security lint rule | 2 |

### Findings by scanner

| Scanner | Count |
| --- | --- |
| ESLint | 5 |
| Gitleaks | 5 |
| Semgrep | 57 |
| Trivy | 2 |

## 6. Top findings

### 1. A query string parameter may contain a URL value that could cause the web application to redirect the request to a malicious website controlled by an attacker. Make sure to sanitize this parameter sufficiently.

| Field | Value |
| --- | --- |
| Finding ID | 2dbf78c41d0dd0f8 |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | Controllers/HomeController.cs:164 |
| Rule | scanner_output.semgrep-configs.csharp.lang.security.open-redirect |
| CWE | CWE-601 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://cwe.mitre.org/data/definitions/601.html |

Evidence summary: A query string parameter may contain a URL value that could cause the web application to redirect the request to a malicious website controlled by an attacker. Make sure to sanitize this parameter sufficiently.

### 2. By not specifying a USER, a program in the container may run as 'root'. This is a security hazard. If an attacker can control a process running as root, they may have control over the container. Ensure that the last USER

| Field | Value |
| --- | --- |
| Finding ID | 74650f3c7abae766 |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | Dockerfile:21 |
| Rule | scanner_output.semgrep-configs.dockerfile.security.missing-user-entrypoint |
| CWE | CWE-269 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A04_2021-Insecure_Design |

Evidence summary: By not specifying a USER, a program in the container may run as 'root'. This is a security hazard. If an attacker can control a process running as root, they may have control over the container. Ensure that the last USER in a Dockerfile is a USER other than 'root'.

### 3. User controlled data in methods like 'innerHTML', 'outerHTML' or 'document.write' is an anti-pattern that can lead to XSS vulnerabilities

| Field | Value |
| --- | --- |
| Finding ID | a1d313ce48d2c6e0 |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | wwwroot/LLM-js/ea.js:20 |
| Rule | scanner_output.semgrep-configs.javascript.browser.security.insecure-document-method |
| CWE | CWE-79 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A03_2021-Injection |

Evidence summary: User controlled data in methods like 'innerHTML', 'outerHTML' or 'document.write' is an anti-pattern that can lead to XSS vulnerabilities

### 4. User controlled data in a 'bubble.innerHTML' is an anti-pattern that can lead to XSS vulnerabilities

| Field | Value |
| --- | --- |
| Finding ID | f417c3bb63d6e49b |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | wwwroot/LLM-js/ea.js:20 |
| Rule | scanner_output.semgrep-configs.javascript.browser.security.insecure-innerhtml |
| CWE | CWE-79 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A03_2021-Injection |

Evidence summary: User controlled data in a 'bubble.innerHTML' is an anti-pattern that can lead to XSS vulnerabilities

### 5. User controlled data in methods like 'innerHTML', 'outerHTML' or 'document.write' is an anti-pattern that can lead to XSS vulnerabilities

| Field | Value |
| --- | --- |
| Finding ID | 9176aa92816c7cc3 |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | wwwroot/LLM-js/ioh.js:22 |
| Rule | scanner_output.semgrep-configs.javascript.browser.security.insecure-document-method |
| CWE | CWE-79 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A03_2021-Injection |

Evidence summary: User controlled data in methods like 'innerHTML', 'outerHTML' or 'document.write' is an anti-pattern that can lead to XSS vulnerabilities

### 6. User controlled data in a 'bubble.innerHTML' is an anti-pattern that can lead to XSS vulnerabilities

| Field | Value |
| --- | --- |
| Finding ID | 2f7d9e9b5d4acec1 |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | wwwroot/LLM-js/ioh.js:22 |
| Rule | scanner_output.semgrep-configs.javascript.browser.security.insecure-innerhtml |
| CWE | CWE-79 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A03_2021-Injection |

Evidence summary: User controlled data in a 'bubble.innerHTML' is an anti-pattern that can lead to XSS vulnerabilities

### 7. User controlled data in methods like 'innerHTML', 'outerHTML' or 'document.write' is an anti-pattern that can lead to XSS vulnerabilities

| Field | Value |
| --- | --- |
| Finding ID | 27453d770f5ada21 |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | wwwroot/LLM-js/pi.js:20 |
| Rule | scanner_output.semgrep-configs.javascript.browser.security.insecure-document-method |
| CWE | CWE-79 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A03_2021-Injection |

Evidence summary: User controlled data in methods like 'innerHTML', 'outerHTML' or 'document.write' is an anti-pattern that can lead to XSS vulnerabilities

### 8. User controlled data in a 'bubble.innerHTML' is an anti-pattern that can lead to XSS vulnerabilities

| Field | Value |
| --- | --- |
| Finding ID | 25d6701cd92b4f4f |
| Scanner | Semgrep |
| Severity | HIGH |
| Evidence location | wwwroot/LLM-js/pi.js:20 |
| Rule | scanner_output.semgrep-configs.javascript.browser.security.insecure-innerhtml |
| CWE | CWE-79 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A03_2021-Injection |

Evidence summary: User controlled data in a 'bubble.innerHTML' is an anti-pattern that can lead to XSS vulnerabilities

### 9. Image user should not be 'root'

| Field | Value |
| --- | --- |
| Finding ID | ca5af16b804151a4 |
| Scanner | Trivy |
| Severity | HIGH |
| Evidence location | Dockerfile |
| Rule | DS-0002 |
| CWE | Not supplied |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | trivy_output_offline.json |
| Reference | https://avd.aquasec.com/misconfig/ds-0002 |

Evidence summary: Running containers with 'root' user can lead to a container escape situation. It is a best practice to run containers as non-root users, which can be done by adding a 'USER' statement to the Dockerfile.

### 10. GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling supply-chain attacks — as seen in the trivy-action and kics-github-action compromi

| Field | Value |
| --- | --- |
| Finding ID | 2407604f9ec0730a |
| Scanner | Semgrep |
| Severity | MEDIUM |
| Evidence location | .github/workflows/dotnet.yml:15 |
| Rule | scanner_output.semgrep-configs.yaml.github-actions.security.github-actions-mutable-action-tag |
| CWE | CWE-1357, CWE-353 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions#using-third-party-actions |

Evidence summary: GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling supply-chain attacks — as seen in the trivy-action and kics-github-action compromises. Pin the reference to a full 40-character commit SHA instead, e.g. 'uses: actions/checkout@8ade135a41bc03ea155e62e844d188df1ea18608'.

### 11. GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling supply-chain attacks — as seen in the trivy-action and kics-github-action compromi

| Field | Value |
| --- | --- |
| Finding ID | 6b437f6261e54877 |
| Scanner | Semgrep |
| Severity | MEDIUM |
| Evidence location | .github/workflows/dotnet.yml:18 |
| Rule | scanner_output.semgrep-configs.yaml.github-actions.security.github-actions-mutable-action-tag |
| CWE | CWE-1357, CWE-353 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions#using-third-party-actions |

Evidence summary: GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling supply-chain attacks — as seen in the trivy-action and kics-github-action compromises. Pin the reference to a full 40-character commit SHA instead, e.g. 'uses: actions/checkout@8ade135a41bc03ea155e62e844d188df1ea18608'.

### 12. GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling supply-chain attacks — as seen in the trivy-action and kics-github-action compromi

| Field | Value |
| --- | --- |
| Finding ID | 5bc6be24f479fdb3 |
| Scanner | Semgrep |
| Severity | MEDIUM |
| Evidence location | .github/workflows/dotnet.yml:23 |
| Rule | scanner_output.semgrep-configs.yaml.github-actions.security.github-actions-mutable-action-tag |
| CWE | CWE-1357, CWE-353 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions#using-third-party-actions |

Evidence summary: GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling supply-chain attacks — as seen in the trivy-action and kics-github-action compromises. Pin the reference to a full 40-character commit SHA instead, e.g. 'uses: actions/checkout@8ade135a41bc03ea155e62e844d188df1ea18608'.

### 13. GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling supply-chain attacks — as seen in the trivy-action and kics-github-action compromi

| Field | Value |
| --- | --- |
| Finding ID | 9d42e0029c62fe63 |
| Scanner | Semgrep |
| Severity | MEDIUM |
| Evidence location | .github/workflows/dotnet.yml:52 |
| Rule | scanner_output.semgrep-configs.yaml.github-actions.security.github-actions-mutable-action-tag |
| CWE | CWE-1357, CWE-353 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions#using-third-party-actions |

Evidence summary: GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling supply-chain attacks — as seen in the trivy-action and kics-github-action compromises. Pin the reference to a full 40-character commit SHA instead, e.g. 'uses: actions/checkout@8ade135a41bc03ea155e62e844d188df1ea18608'.

### 14. An action sourced from a third-party repository on GitHub is not pinned to a full length commit SHA. Pinning an action to a full length commit SHA is currently the only way to use an action as an immutable release. Pinni

| Field | Value |
| --- | --- |
| Finding ID | d83770945546ff62 |
| Scanner | Semgrep |
| Severity | MEDIUM |
| Evidence location | .github/workflows/dotnet.yml:55 |
| Rule | scanner_output.semgrep-configs.yaml.github-actions.security.audit.third-party-action-not-pinned-to-commit-sha |
| CWE | CWE-1357, CWE-353 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A06_2021-Vulnerable_and_Outdated_Components |

Evidence summary: An action sourced from a third-party repository on GitHub is not pinned to a full length commit SHA. Pinning an action to a full length commit SHA is currently the only way to use an action as an immutable release. Pinning to a particular SHA helps mitigate the risk of a bad actor adding a backdoor to the action's repository, as they would need to generate a SHA-1 collision for a valid Git object payload.

### 15. GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling supply-chain attacks — as seen in the trivy-action and kics-github-action compromi

| Field | Value |
| --- | --- |
| Finding ID | c944f05be72161ca |
| Scanner | Semgrep |
| Severity | MEDIUM |
| Evidence location | .github/workflows/dotnet.yml:55 |
| Rule | scanner_output.semgrep-configs.yaml.github-actions.security.github-actions-mutable-action-tag |
| CWE | CWE-1357, CWE-353 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions#using-third-party-actions |

Evidence summary: GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling supply-chain attacks — as seen in the trivy-action and kics-github-action compromises. Pin the reference to a full 40-character commit SHA instead, e.g. 'uses: actions/checkout@8ade135a41bc03ea155e62e844d188df1ea18608'.

### 16. An action sourced from a third-party repository on GitHub is not pinned to a full length commit SHA. Pinning an action to a full length commit SHA is currently the only way to use an action as an immutable release. Pinni

| Field | Value |
| --- | --- |
| Finding ID | 911e91c125e24f26 |
| Scanner | Semgrep |
| Severity | MEDIUM |
| Evidence location | .github/workflows/dotnet.yml:58 |
| Rule | scanner_output.semgrep-configs.yaml.github-actions.security.audit.third-party-action-not-pinned-to-commit-sha |
| CWE | CWE-1357, CWE-353 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A06_2021-Vulnerable_and_Outdated_Components |

Evidence summary: An action sourced from a third-party repository on GitHub is not pinned to a full length commit SHA. Pinning an action to a full length commit SHA is currently the only way to use an action as an immutable release. Pinning to a particular SHA helps mitigate the risk of a bad actor adding a backdoor to the action's repository, as they would need to generate a SHA-1 collision for a valid Git object payload.

### 17. GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling supply-chain attacks — as seen in the trivy-action and kics-github-action compromi

| Field | Value |
| --- | --- |
| Finding ID | 2c31b783729ba030 |
| Scanner | Semgrep |
| Severity | MEDIUM |
| Evidence location | .github/workflows/dotnet.yml:58 |
| Rule | scanner_output.semgrep-configs.yaml.github-actions.security.github-actions-mutable-action-tag |
| CWE | CWE-1357, CWE-353 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions#using-third-party-actions |

Evidence summary: GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling supply-chain attacks — as seen in the trivy-action and kics-github-action compromises. Pin the reference to a full 40-character commit SHA instead, e.g. 'uses: actions/checkout@8ade135a41bc03ea155e62e844d188df1ea18608'.

### 18. An action sourced from a third-party repository on GitHub is not pinned to a full length commit SHA. Pinning an action to a full length commit SHA is currently the only way to use an action as an immutable release. Pinni

| Field | Value |
| --- | --- |
| Finding ID | 4d811f58177e5b67 |
| Scanner | Semgrep |
| Severity | MEDIUM |
| Evidence location | .github/workflows/dotnet.yml:65 |
| Rule | scanner_output.semgrep-configs.yaml.github-actions.security.audit.third-party-action-not-pinned-to-commit-sha |
| CWE | CWE-1357, CWE-353 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A06_2021-Vulnerable_and_Outdated_Components |

Evidence summary: An action sourced from a third-party repository on GitHub is not pinned to a full length commit SHA. Pinning an action to a full length commit SHA is currently the only way to use an action as an immutable release. Pinning to a particular SHA helps mitigate the risk of a bad actor adding a backdoor to the action's repository, as they would need to generate a SHA-1 collision for a valid Git object payload.

### 19. GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling supply-chain attacks — as seen in the trivy-action and kics-github-action compromi

| Field | Value |
| --- | --- |
| Finding ID | c13da17833c1dd59 |
| Scanner | Semgrep |
| Severity | MEDIUM |
| Evidence location | .github/workflows/dotnet.yml:65 |
| Rule | scanner_output.semgrep-configs.yaml.github-actions.security.github-actions-mutable-action-tag |
| CWE | CWE-1357, CWE-353 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions#using-third-party-actions |

Evidence summary: GitHub Actions step uses a mutable tag or branch reference. Tags and branch names can be silently repointed by the action owner, enabling supply-chain attacks — as seen in the trivy-action and kics-github-action compromises. Pin the reference to a full 40-character commit SHA instead, e.g. 'uses: actions/checkout@8ade135a41bc03ea155e62e844d188df1ea18608'.

### 20. An action sourced from a third-party repository on GitHub is not pinned to a full length commit SHA. Pinning an action to a full length commit SHA is currently the only way to use an action as an immutable release. Pinni

| Field | Value |
| --- | --- |
| Finding ID | acd19bda1b25171a |
| Scanner | Semgrep |
| Severity | MEDIUM |
| Evidence location | .github/workflows/dotnet.yml:74 |
| Rule | scanner_output.semgrep-configs.yaml.github-actions.security.audit.third-party-action-not-pinned-to-commit-sha |
| CWE | CWE-1357, CWE-353 |
| CVE / advisory | Not supplied |
| Reachability | Not assessed |
| Impact | Requires review |
| Disposition | Unverified |
| Suggested fix | Manual remediation decision required |
| Source | semgrep_output.json |
| Reference | https://owasp.org/Top10/A06_2021-Vulnerable_and_Outdated_Components |

Evidence summary: An action sourced from a third-party repository on GitHub is not pinned to a full length commit SHA. Pinning an action to a full length commit SHA is currently the only way to use an action as an immutable release. Pinning to a particular SHA helps mitigate the risk of a bad actor adding a backdoor to the action's repository, as they would need to generate a SHA-1 collision for a valid Git object payload.

Only the first 20 of 69 findings are expanded here. Complete records are available in consolidated_findings.json.

## 7. Supply chain view

Package scanners identified **8 distinct package/version entries** after consolidation.

An SBOM package entry does not itself represent a vulnerability.

### Vulnerable packages and advisories

No data available.

### Package inventory

| Package | Version / constraint | Direct / transitive | License | Source |
| --- | --- | --- | --- | --- |
| actions/cache | v4 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| actions/checkout | v4 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| actions/setup-dotnet | v3 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| C:\Users\dhrut\OneDrive\Desktop\abb_hackathon\dotnet-aspgoat |  | Unknown | Not identified | Syft SPDX |
| docker/build-push-action | v6 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| docker/login-action | v3 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| docker/metadata-action | v5 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |
| docker/setup-buildx-action | v3 | Unknown | Not identified | Syft CycloneDX, Syft SPDX |

### Repository license

mit

Detected licenses are not a legal compliance determination. Unknown dependency relationships are not inferred.

## 8. Remediation outcomes

No baseline/post-remediation comparison, patch evidence or test results were supplied.

Before-and-after counts, verified fixes and closure status are **not assessed**.

## 9. Limitations

- Static analysis and dependency scanners can produce false positives and false negatives.
- Reachability, exploitability, runtime controls and business impact have not been validated.
- Offline vulnerability databases and rules may be stale. Report timestamps do not prove database freshness.
- A missing or failed scanner must not be interpreted as reporting zero vulnerabilities.
- Source coverage, excluded files and unsupported language features may not be fully established by scanner reports alone.
- Potential secret findings require validation. Matched secret values are withheld.

## 10. Recommendations

1. **Triage ownership:** Assign each finding to a responsible repository or component owner.
2. **Validate findings:** Confirm whether flagged code and dependencies are deployed and reachable. Record false positives.
3. **Fix timelines:** Establish severity-based remediation SLAs using an approved policy.
4. **CI integration:** Integrate scanners into CI and define policy gates with an exception process.
5. **Supply chain:** Update vulnerable dependencies to compatible patched versions and review license obligations.
6. **Offline maintenance:** Periodically refresh scanner rules and vulnerability databases through an approved process.
7. **Remediation verification:** Rerun scans and tests after fixes. Preserve baseline and follow-up reports.

